"use client";
import { useMemo } from "react";

export default function Confetti({ count = 70, colors = ["#a855f7", "#38bdf8", "#f472b6", "#facc15", "#34d399"] }) {
  const bits = useMemo(() => Array.from({ length: count }, (_, i) => ({
    left: Math.random() * 100, delay: Math.random() * 1.8, dur: 2.6 + Math.random() * 2.4,
    size: 6 + Math.random() * 8, color: colors[i % colors.length], round: Math.random() < 0.4,
  })), [count]); // eslint-disable-line
  return (
    <div className="fixed inset-0 pointer-events-none z-[65] overflow-hidden">
      {bits.map((b, i) => (
        <span key={i} className="absolute top-0" style={{
          left: `${b.left}%`, width: b.size, height: b.size * (b.round ? 1 : 0.45), background: b.color,
          borderRadius: b.round ? "50%" : 2, boxShadow: `0 0 8px ${b.color}`,
          animation: `confetti-fall ${b.dur}s ${b.delay}s cubic-bezier(.3,.6,.5,1) forwards`,
        }} />
      ))}
    </div>
  );
}
