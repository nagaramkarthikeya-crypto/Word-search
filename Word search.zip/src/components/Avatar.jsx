import { AVATARS } from "@/utils/gameConstants";

export default function Avatar({ index = 0, size = 48, speaking = false, dim = false, className = "" }) {
  const a = AVATARS[(Number(index) || 0) % AVATARS.length];
  return (
    <div className={`avatar shrink-0 ${speaking ? "speaking" : ""} ${dim ? "opacity-40 grayscale" : ""} ${className}`}
      style={{ width: size, height: size, fontSize: size * 0.55, background: `linear-gradient(140deg, ${a.from}, ${a.to})` }}>
      <span className="relative z-10 drop-shadow">{a.emoji}</span>
    </div>
  );
}
