"use client";
import { createContext, useCallback, useContext, useState } from "react";
import { sfx } from "@/utils/sfx";

const Ctx = createContext(() => {});
export const useToast = () => useContext(Ctx);

export function ToastProvider({ children }) {
  const [items, setItems] = useState([]);
  const push = useCallback((text, type = "info") => {
    const id = Math.random().toString(36).slice(2);
    if (type === "error") sfx.error();
    setItems((l) => [...l, { id, text, type }]);
    setTimeout(() => setItems((l) => l.filter((x) => x.id !== id)), 3200);
  }, []);
  return (
    <Ctx.Provider value={push}>
      {children}
      <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[70] flex flex-col gap-2 w-[92%] max-w-sm pointer-events-none">
        {items.map((t) => (
          <div key={t.id}
            className={`glass glass-strong anim-pop px-4 py-3 text-center font-bold tracking-wide ${t.type === "error" ? "border-rose-400/60 text-rose-200 anim-shake" : t.type === "ok" ? "border-emerald-400/50 text-emerald-200" : ""}`}>
            {t.text}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}
