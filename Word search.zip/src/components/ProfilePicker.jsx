"use client";
import Avatar from "./Avatar";
import { AVATARS } from "@/utils/gameConstants";
import { sfx } from "@/utils/sfx";

export default function ProfilePicker({ name, setName, avatar, setAvatar, error }) {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-4">
        <div className="anim-float"><Avatar index={avatar} size={72} /></div>
        <div className="flex-1">
          <label className="label">Your nickname</label>
          <input className={`input-game mt-1 ${error ? "!border-rose-400 anim-shake" : ""}`} value={name} maxLength={16}
            onChange={(e) => setName(e.target.value)} placeholder="e.g. Karthik" autoComplete="off" />
          {error && <p className="text-rose-300 text-sm font-bold mt-1">{error}</p>}
        </div>
      </div>
      <div className="flex gap-2 overflow-x-auto scroll-thin pb-2">
        {AVATARS.map((_, i) => (
          <button key={i} type="button" onClick={() => { sfx.hover(); setAvatar(i); }} data-on={avatar === i}
            className="select-tile shrink-0 rounded-2xl border border-white/10 p-1.5">
            <Avatar index={i} size={40} />
          </button>
        ))}
      </div>
    </div>
  );
}
