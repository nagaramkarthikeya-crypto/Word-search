"use client";
import { useEffect, useState } from "react";
import { unlockAudio, sfx } from "@/utils/sfx";

const LINES = [
  "INITIALISING SECURE CHANNEL…",
  "LOADING AGENT PROFILES…",
  "ENCRYPTING SECRET WORDS…",
  "SCANNING FOR SPIES…",
  "ALL SYSTEMS READY",
];

// Game boot sequence -> "TAP TO START" (also unlocks audio on mobile)
export default function BootScreen({ onDone }) {
  const [step, setStep] = useState(0);
  const [pct, setPct] = useState(0);
  const [leaving, setLeaving] = useState(false);
  const ready = pct >= 100;

  useEffect(() => {
    const t = setInterval(() => {
      setPct((p) => {
        const n = Math.min(100, p + Math.random() * 9 + 3);
        setStep(Math.min(LINES.length - 1, Math.floor((n / 100) * LINES.length)));
        if (n >= 100) clearInterval(t);
        return n;
      });
    }, 90);
    return () => clearInterval(t);
  }, []);

  function start() {
    if (!ready || leaving) return;
    unlockAudio();
    sfx.boot();
    setLeaving(true);
    setTimeout(onDone, 650);
  }

  useEffect(() => {
    const k = (e) => (e.key === "Enter" || e.key === " ") && start();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  });

  return (
    <div onClick={start}
      className={`fixed inset-0 z-[80] grid place-items-center cursor-pointer transition-all duration-700 ${leaving ? "opacity-0 scale-110 blur-md" : "opacity-100"}`}
      style={{ background: "radial-gradient(circle at 50% 40%, #1a0b3a, #05020c 70%)" }}>
      <div className="flex flex-col items-center gap-8 px-6 text-center">
        <div className="relative w-36 h-36 anim-float">
          <div className="absolute inset-0 rounded-full border-2 border-dashed border-violet-500/60 anim-spin-slow" />
          <div className="absolute inset-3 rounded-full border border-sky-400/50" style={{ animation: "ring-spin 5s linear infinite reverse" }} />
          <div className="absolute inset-0 grid place-items-center text-6xl drop-shadow-[0_0_20px_rgba(168,85,247,.9)]">🕵️</div>
        </div>
        <h1 className="logo glitch text-5xl sm:text-7xl" data-text="SECRET WORD">SECRET WORD</h1>
        <div className="w-72 sm:w-96">
          <div className="h-2 rounded-full bg-white/10 overflow-hidden">
            <div className="h-full rounded-full bg-gradient-to-r from-violet-500 via-fuchsia-500 to-sky-400 shadow-[0_0_14px_rgba(168,85,247,.9)] transition-all"
              style={{ width: `${pct}%` }} />
          </div>
          <div className="mt-3 flex justify-between font-display text-[10px] tracking-[.25em] text-violet-200/70">
            <span>{LINES[step]}</span><span>{Math.floor(pct)}%</span>
          </div>
        </div>
        <div className={`font-display tracking-[.4em] text-lg text-sky-300 transition-opacity duration-500 ${ready ? "opacity-100 anim-blink" : "opacity-0"}`}>
          ▶ TAP TO START
        </div>
      </div>
    </div>
  );
}
