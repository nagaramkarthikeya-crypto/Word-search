"use client";
import { Copy, Share2, Link2 } from "lucide-react";
import { useToast } from "./Toast";
import { inviteLink } from "@/services/roomService";
import { sfx } from "@/utils/sfx";

export default function RoomCode({ code }) {
  const toast = useToast();
  async function copy(text, what) {
    try {
      await navigator.clipboard.writeText(text);
      sfx.click();
      toast(`${what} copied!`, "ok");
    } catch {
      toast("Copy failed — long-press to copy", "error");
    }
  }
  async function share() {
    const url = inviteLink(code);
    if (navigator.share) {
      try {
        await navigator.share({ title: "SECRET WORD", text: `Join my SECRET WORD room! Code: ${code}`, url });
      } catch {}
    } else copy(url, "Invite link");
  }
  return (
    <div className="glass glass-edge hud-frame p-5 text-center">
      <span className="corner tl" /><span className="corner tr" /><span className="corner bl" /><span className="corner br" />
      <div className="label">Room code</div>
      <button onClick={() => copy(code, "Room code")} className="group mt-2 flex justify-center gap-1.5 sm:gap-2 mx-auto" title="Copy code">
        {code.split("").map((c, i) => (
          <span key={i} className="w-10 h-12 sm:w-12 sm:h-14 rounded-xl grid place-items-center font-display text-2xl sm:text-3xl font-black bg-black/30 border border-violet-400/40 text-neon group-hover:border-sky-400 transition anim-pop" style={{ animationDelay: `${i * 0.06}s` }}>{c}</span>
        ))}
      </button>
      <div className="flex gap-2 justify-center mt-4 flex-wrap">
        <button className="btn-game secondary sm" onClick={() => copy(code, "Room code")}><Copy size={14} /> Code</button>
        <button className="btn-game secondary sm" onClick={() => copy(inviteLink(code), "Invite link")}><Link2 size={14} /> Link</button>
        <button className="btn-game sm" onClick={() => { sfx.click(); share(); }}><Share2 size={14} /> Share</button>
      </div>
    </div>
  );
}
