export default function Loader({ text = "Loading…" }) {
  return (
    <div className="min-h-[60vh] grid place-items-center">
      <div className="flex flex-col items-center gap-5">
        <div className="relative w-20 h-20">
          <div className="absolute inset-0 rounded-full border-4 border-violet-500/20" />
          <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-violet-400 border-r-sky-400" style={{ animation: "ring-spin .9s linear infinite" }} />
          <div className="absolute inset-0 grid place-items-center text-3xl">🕵️</div>
        </div>
        <div className="font-display tracking-[.3em] text-xs text-violet-200 anim-glow">{text.toUpperCase()}</div>
      </div>
    </div>
  );
}
