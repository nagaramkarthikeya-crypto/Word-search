"use client";
import { useEffect, useRef, useState } from "react";
import { RotateCcw, LogOut, Film } from "lucide-react";
import Avatar from "./Avatar";
import Confetti from "./Confetti";
import GameButton from "./GameButton";
import Modal from "./Modal";
import { wordLabel } from "@/utils/wordCategories";
import { sfx } from "@/utils/sfx";

export default function ResultsPanel({ room, me, isHost, onPlayAgain, onLeave }) {
  const g = room.game;
  const spy = room.players[g.spyId];
  const spyWon = g.outcome?.winner === "spy";
  const iAmSpy = g.spyId === me;
  const iWon = spyWon === iAmSpy;
  const [stage, setStage] = useState(0); // cinematic reveal steps
  const [replay, setReplay] = useState(false);
  const played = useRef(false);

  useEffect(() => {
    const t1 = setTimeout(() => setStage(1), 700);
    const t2 = setTimeout(() => setStage(2), 1700);
    const t3 = setTimeout(() => setStage(3), 2600);
    return () => [t1, t2, t3].forEach(clearTimeout);
  }, []);
  useEffect(() => {
    if (stage === 3 && !played.current) { played.current = true; iWon ? sfx.win() : sfx.lose(); }
  }, [stage, iWon]);

  const tally = g.tally || {};
  const maxVotes = Math.max(1, ...Object.values(tally));
  const ids = room.order.filter((id) => room.players[id]);

  return (
    <div className="flex flex-col gap-5">
      {stage >= 3 && iWon && <Confetti />}

      <div className={`glass glass-edge hud-frame p-6 sm:p-10 text-center relative overflow-hidden ${stage >= 3 ? (spyWon ? "shadow-[0_0_80px_rgba(251,79,110,.4)]" : "shadow-[0_0_80px_rgba(56,189,248,.4)]") : ""}`}>
        <span className="corner tl" /><span className="corner tr" /><span className="corner bl" /><span className="corner br" />
        <div className="label">Mission debrief · Round {room.round}</div>

        <div className="grid sm:grid-cols-2 gap-6 mt-6 items-center">
          <div className={`flex flex-col items-center gap-3 transition-all duration-700 ${stage >= 1 ? "opacity-100 scale-100" : "opacity-0 scale-75"}`}>
            <div className="label">The Spy was</div>
            <div className="relative">
              <Avatar index={spy?.avatar} size={110} />
              <span className="absolute -bottom-3 left-1/2 -translate-x-1/2 text-4xl">🕵️</span>
            </div>
            <div className="font-display text-2xl font-black text-rose-300">{spy?.name || "Left the game"}{iAmSpy && " (You)"}</div>
          </div>
          <div className={`flex flex-col items-center gap-3 transition-all duration-700 ${stage >= 2 ? "opacity-100 scale-100" : "opacity-0 scale-75"}`}>
            <div className="label">Secret word</div>
            <div className="font-display text-3xl sm:text-4xl font-black text-neon break-words">{wordLabel(g.word)}</div>
            {g.spyGuess !== null && g.accusedId === g.spyId && (
              <div className={`chip ${g.guessedRight ? "!bg-emerald-500/20 !border-emerald-400/40" : "!bg-rose-500/20 !border-rose-400/40"}`}>
                Spy guessed: “{g.spyGuess || "—"}” {g.guessedRight ? "✓" : "✗"}
              </div>
            )}
          </div>
        </div>

        <div className={`mt-8 transition-all duration-700 ${stage >= 3 ? "opacity-100" : "opacity-0 translate-y-4"}`}>
          <div className={`logo glitch text-4xl sm:text-6xl ${stage >= 3 ? "anim-pop" : ""}`} data-text={spyWon ? "SPY WINS" : "AGENTS WIN"}>{spyWon ? "SPY WINS" : "AGENTS WIN"}</div>
          <div className="font-semibold text-[var(--muted)] mt-2">{g.outcome?.reason}</div>
          <div className={`inline-block mt-4 font-display font-black tracking-[.3em] px-4 py-2 border-2 ${iWon ? "text-emerald-300 border-emerald-400" : "text-rose-300 border-rose-400"} anim-stamp`}>
            {iWon ? "VICTORY" : "DEFEAT"}
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-5">
        <div className="glass p-5">
          <div className="label mb-4">Voting results</div>
          <div className="flex flex-col gap-3">
            {ids.sort((a, b) => (tally[b] || 0) - (tally[a] || 0)).map((id) => {
              const p = room.players[id];
              const voters = Object.entries(g.votes || {}).filter(([, t]) => t === id).map(([v]) => room.players[v]?.name).filter(Boolean);
              return (
                <div key={id} className="flex items-center gap-3">
                  <Avatar index={p.avatar} size={34} />
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between text-sm font-bold">
                      <span className="truncate">{p.name} {id === g.spyId && "🕵️"}</span><span>{tally[id] || 0}</span>
                    </div>
                    <div className="h-2.5 rounded-full bg-white/10 overflow-hidden mt-1">
                      <div className={`h-full rounded-full ${id === g.spyId ? "bg-gradient-to-r from-rose-500 to-fuchsia-500" : "bg-gradient-to-r from-violet-500 to-sky-400"}`}
                        style={{ width: stage >= 1 ? `${((tally[id] || 0) / maxVotes) * 100}%` : 0, transition: "width 1s ease" }} />
                    </div>
                    {voters.length > 0 && <div className="text-[11px] text-[var(--muted)] font-semibold mt-0.5 truncate">by {voters.join(", ")}</div>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="glass p-5 flex flex-col gap-3">
          <div className="label">Next mission</div>
          {isHost ? (
            <GameButton onClick={onPlayAgain} className="w-full !py-5 text-lg"><RotateCcw /> Play Again</GameButton>
          ) : (
            <div className="glass p-4 text-center font-semibold text-[var(--muted)]">Waiting for {room.players[room.hostId]?.name} to start the next round…</div>
          )}
          <GameButton variant="secondary" className="w-full" onClick={() => setReplay(true)}><Film size={16} /> Replay round</GameButton>
          <GameButton variant="ghost" size="sm" className="w-full" sound="back" onClick={onLeave}><LogOut size={14} /> Leave room</GameButton>
        </div>
      </div>

      <Modal open={replay} onClose={() => setReplay(false)} title={`Replay · Round ${room.round}`} wide>
        <div className="flex flex-col gap-2 stagger">
          {g.clues.map((c, i) => {
            const p = room.players[c.pid];
            return (
              <div key={i} className="flex items-center gap-3 rounded-2xl bg-black/25 border border-white/10 px-3 py-2.5">
                <span className="font-display text-xs w-6 text-[var(--muted)]">{i + 1}</span>
                <Avatar index={p?.avatar} size={34} />
                <span className="font-bold flex-1">{p?.name || "Left"} {c.pid === g.spyId && <span className="chip !text-[9px] !bg-rose-500/20 !border-rose-400/40 ml-1">SPY</span>}</span>
                <span className={`font-display ${c.skipped ? "text-zinc-500 text-sm" : "text-sky-200"}`}>{c.text}</span>
              </div>
            );
          })}
        </div>
        {(room.history || []).length > 1 && (
          <>
            <div className="label mt-6 mb-2">Earlier rounds</div>
            {[...room.history].reverse().slice(1).map((h) => (
              <div key={h.round} className="flex justify-between text-sm font-semibold py-1.5 border-b border-white/5">
                <span>Round {h.round} · {wordLabel(h.word)}</span>
                <span className={h.winner === "spy" ? "text-rose-300" : "text-sky-300"}>{h.winner === "spy" ? `Spy ${h.spyName} won` : "Agents won"}</span>
              </div>
            ))}
          </>
        )}
      </Modal>
    </div>
  );
}
