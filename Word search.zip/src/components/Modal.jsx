"use client";
import { X } from "lucide-react";
import { sfx } from "@/utils/sfx";

export default function Modal({ open, onClose, title, children, wide = false }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[75] grid place-items-center p-4 bg-black/60 backdrop-blur-sm anim-screen" onClick={() => { sfx.back(); onClose(); }}>
      <div onClick={(e) => e.stopPropagation()}
        className={`glass glass-strong glass-edge hud-frame w-full ${wide ? "max-w-3xl" : "max-w-lg"} max-h-[85vh] overflow-y-auto scroll-thin p-6 sm:p-8 anim-pop`}>
        <span className="corner tl" /><span className="corner tr" /><span className="corner bl" /><span className="corner br" />
        <div className="flex items-center justify-between mb-5">
          <h2 className="title-xl text-xl text-neon">{title}</h2>
          <button onClick={() => { sfx.back(); onClose(); }} className="p-2 rounded-xl hover:bg-white/10" aria-label="Close"><X size={20} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}
