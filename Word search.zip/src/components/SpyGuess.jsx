"use client";
import { useState } from "react";
import { Target } from "lucide-react";
import Avatar from "./Avatar";
import TimerRing from "./TimerRing";
import GameButton from "./GameButton";
import { useToast } from "./Toast";
import { submitSpyGuess } from "@/services/gameService";
import { DURATIONS } from "@/utils/gameConstants";

// Caught Spy gets one comeback guess.
export default function SpyGuess({ room, me, game }) {
  const toast = useToast();
  const [guess, setGuess] = useState("");
  const spy = room.players[room.game.accusedId];
  const iAmSpy = room.game.spyId === me;
  const total = DURATIONS[room.settings.duration]?.guess || 30;

  function send(e) {
    e.preventDefault();
    try { submitSpyGuess(room.code, guess); } catch (x) { toast(x.message, "error"); }
  }

  return (
    <div className="max-w-xl mx-auto flex flex-col items-center gap-6 text-center">
      <div className="relative">
        <Avatar index={spy?.avatar} size={130} />
        <div className="absolute inset-0 grid place-items-center">
          <span className="anim-stamp font-display font-black text-3xl text-rose-400 border-4 border-rose-400 px-3 py-1 bg-black/50">CAUGHT</span>
        </div>
      </div>
      <div>
        <div className="font-display text-3xl font-black">{spy?.name} <span className="text-rose-400">was the Spy!</span></div>
        <p className="text-[var(--muted)] font-semibold mt-2">But it&apos;s not over… one final guess at the secret word.</p>
      </div>
      <TimerRing seconds={game.timeLeft} total={total} size={90} />
      {iAmSpy ? (
        <form onSubmit={send} className="glass glass-edge danger-flash p-5 w-full flex flex-col gap-3">
          <div className="label">Your comeback guess</div>
          <input autoFocus className="input-game text-center text-2xl font-display" maxLength={40} value={guess} onChange={(e) => setGuess(e.target.value)} placeholder="The secret word is…" />
          <GameButton type="submit" variant="danger" disabled={!guess.trim()} className="!py-4"><Target size={18} /> Lock in guess</GameButton>
        </form>
      ) : (
        <div className="glass p-5 w-full font-display tracking-widest anim-glow">THE SPY IS GUESSING…</div>
      )}
    </div>
  );
}
