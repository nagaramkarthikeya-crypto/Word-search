import { Trophy, Medal } from "lucide-react";
import Avatar from "./Avatar";

export default function Scoreboard({ room, me }) {
  const rows = Object.entries(room.scores || {})
    .filter(([id]) => room.players[id])
    .map(([id, s]) => ({ id, ...s, avatar: room.players[id].avatar, name: room.players[id].name }))
    .sort((a, b) => b.points - a.points || b.wins - a.wins);
  const medal = ["text-amber-300", "text-zinc-300", "text-orange-400"];
  return (
    <div className="glass p-5">
      <div className="label mb-4 flex items-center gap-2"><Trophy size={14} /> Scoreboard</div>
      <div className="overflow-x-auto scroll-thin">
        <table className="w-full text-left min-w-[520px]">
          <thead>
            <tr className="label !text-[9px]">
              <th className="py-2 pl-2">#</th><th>Agent</th><th className="text-center">Pts</th><th className="text-center">Wins</th>
              <th className="text-center">Spy wins</th><th className="text-center">Group wins</th><th className="text-center">Word guesses</th>
            </tr>
          </thead>
          <tbody className="stagger">
            {rows.map((r, i) => (
              <tr key={r.id} className={`border-t border-white/5 ${r.id === me ? "bg-violet-500/10" : ""}`}>
                <td className="py-2.5 pl-2 font-display font-black">{i < 3 ? <Medal size={18} className={medal[i]} /> : i + 1}</td>
                <td><div className="flex items-center gap-2 font-bold"><Avatar index={r.avatar} size={30} />{r.name}{r.id === me && <span className="text-[10px] text-violet-300">(YOU)</span>}</div></td>
                <td className="text-center font-display font-black text-neon">{r.points}</td>
                <td className="text-center font-bold">{r.wins}</td>
                <td className="text-center font-bold">{r.spyWins}</td>
                <td className="text-center font-bold">{r.groupWins}</td>
                <td className="text-center font-bold">{r.correctGuesses}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-[var(--muted)] mt-3 font-semibold">Points: win as Spy +3 · win with group +1 · voted for the Spy +1 · correct word guess +1</p>
    </div>
  );
}
