"use client";
import { Crown, X, Bot, WifiOff, Check } from "lucide-react";
import Avatar from "./Avatar";
import { isOnline } from "@/services/localEngine";

export default function PlayerCard({ player, isHost, isMe, onKick, speaking, status, dim, compact = false, badge }) {
  const online = isOnline(player);
  return (
    <div className={`glass relative flex ${compact ? "flex-row px-3 py-2.5 gap-3" : "flex-col items-center p-4 gap-2"} items-center ${isMe ? "glass-edge" : ""} ${speaking ? "shadow-[0_0_30px_rgba(56,189,248,.45)] !border-sky-400/60" : ""} transition`}>
      {onKick && (
        <button onClick={onKick} className="absolute top-1.5 right-1.5 p-1 rounded-lg text-[var(--muted)] hover:text-rose-300 hover:bg-rose-500/20" aria-label="Remove">
          <X size={14} />
        </button>
      )}
      <div className="relative">
        <Avatar index={player.avatar} size={compact ? 40 : 60} speaking={speaking} dim={dim || !online} />
        {isHost && <Crown size={compact ? 14 : 18} className="absolute -top-2 -right-2 text-amber-300 drop-shadow-[0_0_6px_#fbbf24] fill-amber-300" />}
        <span className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#120826] ${online ? "bg-emerald-400" : "bg-zinc-500"}`} />
      </div>
      <div className={`min-w-0 ${compact ? "flex-1" : "text-center w-full"}`}>
        <div className="font-bold truncate flex items-center gap-1 justify-center">
          {player.isBot && <Bot size={13} className="text-sky-300 shrink-0" />}
          <span className="truncate">{player.name}</span>
          {isMe && <span className="text-[10px] text-violet-300 font-display">(YOU)</span>}
        </div>
        {!compact && <div className="label !text-[9px]">{isHost ? "Host" : online ? "Ready" : "Offline"}</div>}
      </div>
      {status === "voted" && <span className="chip !text-[10px] !bg-emerald-500/20 !border-emerald-400/40"><Check size={11} /> voted</span>}
      {status === "offline" && <WifiOff size={14} className="text-zinc-400" />}
      {badge}
    </div>
  );
}
