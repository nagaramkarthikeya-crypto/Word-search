"use client";
import { useState } from "react";
import { Lock, Gavel, Check } from "lucide-react";
import Avatar from "./Avatar";
import TimerRing from "./TimerRing";
import GameButton from "./GameButton";
import { useToast } from "./Toast";
import { castVote, hostEndVoting } from "@/services/gameService";
import { isOnline } from "@/services/localEngine";
import { DURATIONS } from "@/utils/gameConstants";
import { sfx } from "@/utils/sfx";

export default function VotingPanel({ room, me, isHost, game }) {
  const toast = useToast();
  const [pick, setPick] = useState(null);
  const g = room.game;
  const total = DURATIONS[room.settings.duration]?.vote || 60;
  const voters = room.order.filter((id) => room.players[id] && isOnline(room.players[id]));
  const myClue = (id) => [...g.clues].reverse().find((c) => c.pid === id && !c.skipped)?.text;

  function confirm() {
    try {
      castVote(room.code, pick);
      sfx.vote();
      toast("Vote locked in 🔒", "ok");
    } catch (e) {
      toast(e.message, "error");
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="glass glass-edge p-5 flex items-center gap-4">
        <TimerRing seconds={game.timeLeft} total={total} size={70} />
        <div className="flex-1">
          <div className="label">{g.revoteCount ? "Revote — tied players only" : "Secret ballot"}</div>
          <div className="font-display text-xl sm:text-2xl font-black">WHO IS THE SPY?</div>
          <div className="mt-2 h-2.5 rounded-full bg-white/10 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-violet-500 to-sky-400 transition-all duration-500 shadow-[0_0_10px_#a855f7]"
              style={{ width: `${(game.votedCount / Math.max(1, voters.length)) * 100}%` }} />
          </div>
          <div className="text-sm font-bold text-[var(--muted)] mt-1">{game.votedCount}/{voters.length} votes in · choices hidden until the end</div>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 stagger">
        {g.candidates.map((id) => {
          const p = room.players[id];
          if (!p) return null;
          const self = id === me;
          const selected = (game.myVote || pick) === id;
          return (
            <button key={id} disabled={self || !!game.myVote}
              onClick={() => { sfx.hover(); setPick(id); }}
              className={`glass relative p-4 flex flex-col items-center gap-2 transition ${selected ? "!border-rose-400 shadow-[0_0_30px_rgba(251,79,110,.5)] -translate-y-1" : "hover:-translate-y-1"} ${self ? "opacity-50 cursor-not-allowed" : ""}`}>
              {game.hasVoted(id) && <span className="absolute top-2 left-2 w-6 h-6 rounded-full bg-emerald-500/80 grid place-items-center"><Check size={14} /></span>}
              {selected && <span className="absolute top-2 right-2 text-xl anim-pop">🎯</span>}
              <Avatar index={p.avatar} size={64} />
              <div className="font-bold truncate w-full text-center">{self ? "You" : p.name}</div>
              <div className="text-xs font-display tracking-wide text-sky-200 truncate w-full text-center">“{myClue(id) || "…"}”</div>
            </button>
          );
        })}
      </div>

      <div className="flex flex-wrap gap-3 items-center">
        {game.myVote ? (
          <div className="glass px-5 py-3 flex items-center gap-2 font-bold"><Lock size={16} className="text-emerald-300" /> Vote locked. Waiting for others…</div>
        ) : (
          <GameButton onClick={confirm} disabled={!pick} variant="danger" className="flex-1 sm:flex-none !py-4" sound="">
            <Gavel size={18} /> {pick ? `Accuse ${room.players[pick]?.name}` : "Pick a suspect"}
          </GameButton>
        )}
        {isHost && <GameButton variant="secondary" size="sm" onClick={() => { try { hostEndVoting(room.code); } catch (e) { toast(e.message, "error"); } }}>End voting now</GameButton>}
      </div>
    </div>
  );
}
