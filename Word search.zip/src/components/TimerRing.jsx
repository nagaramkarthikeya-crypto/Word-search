"use client";
import { useEffect, useRef } from "react";
import { sfx } from "@/utils/sfx";

// Circular countdown. Ticks + turns red in the last 5 seconds.
export default function TimerRing({ seconds, total, size = 84 }) {
  const last = useRef(seconds);
  useEffect(() => {
    if (seconds !== last.current && seconds <= 5 && seconds > 0) sfx.tick();
    last.current = seconds;
  }, [seconds]);
  const r = size / 2 - 6;
  const C = 2 * Math.PI * r;
  const p = total ? Math.max(0, Math.min(1, seconds / total)) : 0;
  const hot = seconds <= 5;
  return (
    <div className={`relative grid place-items-center ${hot ? "anim-shake" : ""}`} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(255,255,255,.1)" strokeWidth="6" fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} strokeWidth="6" fill="none" strokeLinecap="round"
          stroke={hot ? "#fb4f6e" : "url(#tg)"} strokeDasharray={C} strokeDashoffset={C * (1 - p)}
          style={{ transition: "stroke-dashoffset .3s linear", filter: `drop-shadow(0 0 6px ${hot ? "#fb4f6e" : "#a855f7"})` }} />
        <defs>
          <linearGradient id="tg" x1="0" x2="1"><stop offset="0" stopColor="#a855f7" /><stop offset="1" stopColor="#38bdf8" /></linearGradient>
        </defs>
      </svg>
      <span className={`absolute font-display font-black ${hot ? "text-rose-400" : ""}`} style={{ fontSize: size * 0.3 }}>{seconds}</span>
    </div>
  );
}
