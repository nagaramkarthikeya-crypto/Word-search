"use client";
import { useEffect, useState } from "react";
import GameBackground from "./GameBackground";
import BootScreen from "./BootScreen";
import Navbar from "./Navbar";
import { ToastProvider } from "./Toast";
import { unlockAudio } from "@/utils/sfx";

export default function GameShell({ children }) {
  const [booted, setBooted] = useState(true);

  useEffect(() => {
    if (localStorage.getItem("sw_theme") === "light") document.documentElement.classList.add("light");
    if (!sessionStorage.getItem("sw_booted")) setBooted(false);
    const unlock = () => unlockAudio();
    window.addEventListener("pointerdown", unlock, { once: true });
    return () => window.removeEventListener("pointerdown", unlock);
  }, []);

  return (
    <ToastProvider>
      <div className="screen-fx min-h-dvh flex flex-col">
        <GameBackground />
        {!booted && <BootScreen onDone={() => { sessionStorage.setItem("sw_booted", "1"); setBooted(true); }} />}
        <Navbar />
        <main className="flex-1 w-full max-w-6xl mx-auto px-3 sm:px-5 py-5 sm:py-8">{children}</main>
      </div>
    </ToastProvider>
  );
}
