"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Volume2, VolumeX, Moon, Sun, Users } from "lucide-react";
import { isMuted, setMuted, sfx } from "@/utils/sfx";
import { getOnlineCount } from "@/services/roomService";
import { getProfile } from "@/services/playerService";
import Avatar from "./Avatar";

// In-game HUD bar
export default function Navbar() {
  const [muted, setM] = useState(false);
  const [light, setLight] = useState(false);
  const [online, setOnline] = useState(0);
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    setM(isMuted());
    setLight(document.documentElement.classList.contains("light"));
    setProfile(getProfile());
    const upd = () => { setOnline(getOnlineCount()); setProfile(getProfile()); };
    upd();
    const t = setInterval(upd, 4000);
    return () => clearInterval(t);
  }, []);

  function toggleSound() { setMuted(!muted); setM(!muted); if (muted) sfx.click(); }
  function toggleTheme() {
    const v = !light;
    document.documentElement.classList.toggle("light", v);
    localStorage.setItem("sw_theme", v ? "light" : "dark");
    setLight(v);
    sfx.click();
  }

  return (
    <header className="sticky top-0 z-50 px-3 sm:px-5 pt-3">
      <div className="glass mx-auto max-w-6xl flex items-center gap-3 px-3 sm:px-4 py-2.5 !rounded-2xl">
        <Link href="/" onClick={() => sfx.back()} className="flex items-center gap-2 mr-auto">
          <span className="text-2xl">🕵️</span>
          <span className="logo text-sm sm:text-base">SECRET WORD</span>
        </Link>
        <span className="chip !text-[10px] sm:!text-xs" title="Players online">
          <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399] anim-glow" />
          <Users size={13} /> {online} online
        </span>
        <button onClick={toggleSound} className="p-2 rounded-xl hover:bg-white/10" aria-label="Sound">{muted ? <VolumeX size={19} /> : <Volume2 size={19} />}</button>
        <button onClick={toggleTheme} className="p-2 rounded-xl hover:bg-white/10" aria-label="Theme">{light ? <Moon size={19} /> : <Sun size={19} />}</button>
        {profile?.name ? (
          <div className="hidden sm:flex items-center gap-2 pl-2 border-l border-white/10">
            <Avatar index={profile.avatar} size={30} />
            <span className="font-bold text-sm max-w-24 truncate">{profile.name}</span>
          </div>
        ) : null}
      </div>
    </header>
  );
}
