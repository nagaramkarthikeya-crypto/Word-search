"use client";
import { useEffect, useRef, useState } from "react";
import { Send, SkipForward, Vote, Eye } from "lucide-react";
import Avatar from "./Avatar";
import TimerRing from "./TimerRing";
import GameButton from "./GameButton";
import SecretCard from "./SecretCard";
import Modal from "./Modal";
import { useToast } from "./Toast";
import { submitClue, hostSkipTurn, hostStartVoting } from "@/services/gameService";
import { DURATIONS } from "@/utils/gameConstants";
import { sfx } from "@/utils/sfx";

export default function ClueRound({ room, me, isHost, game }) {
  const toast = useToast();
  const [text, setText] = useState("");
  const [peek, setPeek] = useState(false);
  const g = room.game;
  const total = DURATIONS[room.settings.duration]?.clue || 35;
  const current = room.players[game.currentTurnId];
  const logRef = useRef(null);
  const wasMyTurn = useRef(false);

  useEffect(() => {
    if (game.isMyTurn && !wasMyTurn.current) sfx.join();
    wasMyTurn.current = game.isMyTurn;
  }, [game.isMyTurn]);
  useEffect(() => { logRef.current?.scrollTo({ top: 99999, behavior: "smooth" }); }, [g.clues.length]);

  function send(e) {
    e?.preventDefault();
    try {
      submitClue(room.code, text);
      setText("");
      sfx.vote();
    } catch (x) {
      toast(x.message, "error");
    }
  }
  const act = (fn) => { try { fn(room.code); } catch (x) { toast(x.message, "error"); } };

  return (
    <div className="grid lg:grid-cols-[1fr_360px] gap-5">
      <div className="flex flex-col gap-5">
        {/* turn order strip */}
        <div className="glass p-3 flex gap-3 overflow-x-auto scroll-thin">
          {g.turnOrder.map((id, i) => {
            const p = room.players[id];
            if (!p) return null;
            const done = i < g.turnIndex;
            const now = i === g.turnIndex;
            return (
              <div key={id} className={`flex flex-col items-center gap-1 shrink-0 w-16 transition ${now ? "scale-110" : done ? "opacity-50" : "opacity-80"}`}>
                <Avatar index={p.avatar} size={42} speaking={now} />
                <span className={`text-[11px] font-bold truncate w-full text-center ${now ? "text-sky-300" : ""}`}>{id === me ? "You" : p.name}</span>
              </div>
            );
          })}
        </div>

        {/* spotlight */}
        <div className={`glass glass-edge hud-frame p-6 sm:p-8 text-center relative overflow-hidden ${game.isMyTurn ? "shadow-[0_0_60px_rgba(56,189,248,.35)]" : ""}`}>
          <span className="corner tl" /><span className="corner tr" /><span className="corner bl" /><span className="corner br" />
          <div className="absolute right-4 top-4"><TimerRing seconds={game.timeLeft} total={total} size={72} /></div>
          <div className="label">Now speaking · {Math.min(g.turnIndex + 1, g.turnOrder.length)}/{g.turnOrder.length}</div>
          {current && (
            <div key={current.id} className="flex flex-col items-center gap-3 mt-4 anim-pop">
              <Avatar index={current.avatar} size={96} speaking />
              <div className="font-display text-2xl font-black">{current.id === me ? "YOUR TURN!" : current.name}</div>
            </div>
          )}
          {game.isMyTurn ? (
            <form onSubmit={send} className="mt-6 flex gap-2 max-w-md mx-auto">
              <input autoFocus className="input-game" maxLength={40} value={text} onChange={(e) => setText(e.target.value)} placeholder="Type one clue…" />
              <GameButton type="submit" className="!px-5" sound=""><Send size={18} /></GameButton>
            </form>
          ) : (
            <p className="mt-5 text-[var(--muted)] font-semibold">{current?.isBot ? "Bot is thinking…" : "Listen carefully. Is their clue a little too vague?"}</p>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          <GameButton variant="secondary" size="sm" onClick={() => setPeek(true)}><Eye size={14} /> Peek my card</GameButton>
          {isHost && (
            <>
              <GameButton variant="secondary" size="sm" onClick={() => act(hostSkipTurn)}><SkipForward size={14} /> Skip turn</GameButton>
              <GameButton variant="secondary" size="sm" onClick={() => act(hostStartVoting)}><Vote size={14} /> Start voting now</GameButton>
            </>
          )}
        </div>
      </div>

      <div className="glass p-5 flex flex-col max-h-[70vh]">
        <div className="label mb-3">Clue log</div>
        <div ref={logRef} className="flex-1 overflow-y-auto scroll-thin flex flex-col gap-2 stagger">
          {g.clues.length === 0 && <p className="text-[var(--muted)] font-semibold">No clues yet…</p>}
          {g.clues.map((c, i) => {
            const p = room.players[c.pid];
            return (
              <div key={i} className="flex items-center gap-3 rounded-2xl bg-black/25 border border-white/10 px-3 py-2.5">
                <Avatar index={p?.avatar} size={34} />
                <div className="min-w-0">
                  <div className="text-xs text-[var(--muted)] font-bold">{p?.name || "Left"}</div>
                  <div className={`font-display tracking-wide ${c.skipped ? "text-zinc-500 text-sm" : "text-lg text-sky-200"}`}>{c.text}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <Modal open={peek} onClose={() => setPeek(false)} title="Your card"><SecretCard secret={game.secret} small /></Modal>
    </div>
  );
}
