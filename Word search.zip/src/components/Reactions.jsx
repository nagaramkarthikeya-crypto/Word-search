"use client";
import { useEffect, useRef, useState } from "react";
import { REACTIONS } from "@/utils/gameConstants";
import { sendReaction } from "@/services/roomService";
import { sfx, haptic } from "@/utils/sfx";

// Funny reaction bar + emojis that float up on every player's screen.
export default function Reactions({ room }) {
  const [floating, setFloating] = useState([]);
  const seen = useRef(new Set());
  const [cool, setCool] = useState(false);

  useEffect(() => {
    if (!room) return;
    const fresh = (room.reactions || []).filter((r) => !seen.current.has(r.id) && Date.now() - r.at < 4000);
    fresh.forEach((r) => {
      seen.current.add(r.id);
      const name = room.players[r.pid]?.name || "";
      setFloating((l) => [...l, { ...r, name, left: 10 + Math.random() * 80 }]);
      setTimeout(() => setFloating((l) => l.filter((x) => x.id !== r.id)), 2600);
    });
    (room.reactions || []).forEach((r) => seen.current.add(r.id));
  }, [room]);

  function send(e) {
    if (cool) return;
    sfx.hover();
    haptic(8);
    sendReaction(room.code, e);
    setCool(true);
    setTimeout(() => setCool(false), 700);
  }

  return (
    <>
      <div className="fixed inset-0 pointer-events-none z-[55] overflow-hidden">
        {floating.map((f) => (
          <div key={f.id} className="absolute bottom-24 flex flex-col items-center" style={{ left: `${f.left}%`, animation: "float-up 2.6s ease-out forwards" }}>
            <span className="text-5xl drop-shadow-[0_0_14px_rgba(168,85,247,.9)]">{f.emoji}</span>
            <span className="text-[11px] font-bold mt-1 px-2 rounded-full bg-black/40">{f.name}</span>
          </div>
        ))}
      </div>
      <div className="glass flex gap-1 p-1.5 overflow-x-auto scroll-thin">
        {REACTIONS.map((e) => (
          <button key={e} onClick={() => send(e)} disabled={cool}
            className="text-2xl w-11 h-11 rounded-xl hover:bg-white/10 active:scale-90 transition disabled:opacity-50 shrink-0">{e}</button>
        ))}
      </div>
    </>
  );
}
