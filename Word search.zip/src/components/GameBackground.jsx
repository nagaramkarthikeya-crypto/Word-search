"use client";
import { useEffect, useRef } from "react";

// Animated "game world" backdrop: drifting particles that link into a network,
// floating hidden-word glyphs, and a neon perspective grid floor.
export default function GameBackground() {
  const ref = useRef(null);

  useEffect(() => {
    const c = ref.current;
    const ctx = c.getContext("2d");
    let w, h, raf, dpr;
    const glyphs = ["?", "SPY", "★", "◆", "WORD", "?", "◎", "✦"];
    let pts = [];
    let words = [];
    const mouse = { x: -999, y: -999 };

    function resize() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = c.width = window.innerWidth * dpr;
      h = c.height = window.innerHeight * dpr;
      c.style.width = window.innerWidth + "px";
      c.style.height = window.innerHeight + "px";
      const n = Math.min(90, Math.floor((window.innerWidth * window.innerHeight) / 16000));
      pts = Array.from({ length: n }, () => ({
        x: Math.random() * w, y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.25 * dpr, vy: (Math.random() - 0.5) * 0.25 * dpr,
        r: (Math.random() * 1.6 + 0.6) * dpr, hue: Math.random() < 0.5 ? 270 : 200,
      }));
      words = Array.from({ length: 9 }, () => ({
        t: glyphs[Math.floor(Math.random() * glyphs.length)],
        x: Math.random() * w, y: Math.random() * h, s: (12 + Math.random() * 22) * dpr,
        v: (0.1 + Math.random() * 0.25) * dpr, a: Math.random() * Math.PI * 2,
      }));
    }

    function frame(t) {
      ctx.clearRect(0, 0, w, h);
      const light = document.documentElement.classList.contains("light");
      // glyphs
      ctx.textAlign = "center";
      for (const g of words) {
        g.y -= g.v;
        g.a += 0.01;
        if (g.y < -40) { g.y = h + 40; g.x = Math.random() * w; }
        ctx.font = `800 ${g.s}px Orbitron, sans-serif`;
        ctx.fillStyle = light ? `rgba(110,60,220,${0.08 + Math.sin(g.a) * 0.04})` : `rgba(168,85,247,${0.07 + Math.sin(g.a) * 0.04})`;
        ctx.fillText(g.t, g.x + Math.sin(g.a) * 10 * dpr, g.y);
      }
      // particles + links
      const link = 130 * dpr;
      for (let i = 0; i < pts.length; i++) {
        const p = pts[i];
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;
        const dxm = p.x - mouse.x * dpr, dym = p.y - mouse.y * dpr;
        const dm = Math.hypot(dxm, dym);
        if (dm < 120 * dpr) { p.x += (dxm / dm) * 1.2; p.y += (dym / dm) * 1.2; }
        for (let j = i + 1; j < pts.length; j++) {
          const q = pts[j];
          const d = Math.hypot(p.x - q.x, p.y - q.y);
          if (d < link) {
            ctx.strokeStyle = `hsla(${p.hue},90%,${light ? 45 : 65}%,${(1 - d / link) * 0.22})`;
            ctx.lineWidth = dpr * 0.8;
            ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke();
          }
        }
        const tw = 0.6 + Math.sin(t / 600 + i) * 0.4;
        ctx.fillStyle = `hsla(${p.hue},95%,${light ? 50 : 70}%,${tw})`;
        ctx.shadowColor = `hsl(${p.hue},95%,65%)`;
        ctx.shadowBlur = 8 * dpr;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
        ctx.shadowBlur = 0;
      }
      raf = requestAnimationFrame(frame);
    }

    const onMove = (e) => { mouse.x = e.clientX; mouse.y = e.clientY; };
    resize();
    raf = requestAnimationFrame(frame);
    window.addEventListener("resize", resize);
    window.addEventListener("pointermove", onMove);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("pointermove", onMove);
    };
  }, []);

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      <canvas ref={ref} className="absolute inset-0" />
      {/* neon perspective floor */}
      <div className="absolute left-[-50%] right-[-50%] bottom-[-10%] h-[45vh] opacity-40"
        style={{
          transform: "perspective(420px) rotateX(62deg)",
          backgroundImage: "linear-gradient(rgba(168,85,247,.55) 1px, transparent 1px), linear-gradient(90deg, rgba(56,189,248,.45) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
          maskImage: "linear-gradient(to top, black 10%, transparent 90%)",
          WebkitMaskImage: "linear-gradient(to top, black 10%, transparent 90%)",
          animation: "grid-move 3s linear infinite",
        }} />
      <style>{`@keyframes grid-move { to { background-position: 0 60px, 0 0; } }`}</style>
      {/* glow orbs */}
      <div className="absolute -top-40 -left-40 w-[520px] h-[520px] rounded-full blur-[120px] opacity-40 bg-violet-600 anim-glow" />
      <div className="absolute -bottom-40 -right-40 w-[520px] h-[520px] rounded-full blur-[120px] opacity-30 bg-sky-500 anim-glow" />
    </div>
  );
}
