import { Users, KeyRound, MessageSquareText, Vote, Trophy } from "lucide-react";

export const STEPS = [
  { icon: Users, title: "Gather 5–10 agents", text: "Create a private room and share the 6-character code." },
  { icon: KeyRound, title: "Check your card", text: "Everyone gets the same secret word — except one SPY." },
  { icon: MessageSquareText, title: "Drop one clue", text: "Say one word about it. Too obvious helps the Spy, too vague looks suspicious." },
  { icon: Vote, title: "Vote the Spy", text: "Discuss, then vote. Votes stay hidden until everyone's in." },
  { icon: Trophy, title: "Final twist", text: "Caught Spy gets one guess at the word. Right guess = Spy steals the win!" },
];

export default function HowToPlay({ compact = false }) {
  return (
    <ol className={`stagger grid gap-3 ${compact ? "" : "sm:grid-cols-2"}`}>
      {STEPS.map((s, i) => (
        <li key={s.title} className="glass flex gap-4 p-4 items-start">
          <div className="relative shrink-0 w-11 h-11 rounded-xl grid place-items-center bg-gradient-to-br from-violet-600 to-sky-500 shadow-[0_0_18px_rgba(168,85,247,.6)]">
            <s.icon size={20} />
            <span className="absolute -top-2 -left-2 w-5 h-5 rounded-full bg-black text-[10px] font-display grid place-items-center border border-violet-400">{i + 1}</span>
          </div>
          <div>
            <div className="font-display text-sm tracking-widest uppercase">{s.title}</div>
            <p className="text-[var(--muted)] font-medium leading-snug mt-1">{s.text}</p>
          </div>
        </li>
      ))}
    </ol>
  );
}
