"use client";
import { useEffect, useRef, useState } from "react";
import { sfx } from "@/utils/sfx";

const TEXT = {
  reveal: ["ROUND START", "Check your secret card"],
  clues: ["CLUE ROUND", "One clue each — choose wisely"],
  voting: ["VOTING", "Who is the Spy?"],
  spyGuess: ["SPY CAUGHT?!", "Last chance to guess the word"],
};

// Full-screen cinematic banner whenever the phase changes.
export default function PhaseBanner({ phase, round, revote }) {
  const [show, setShow] = useState(null);
  const last = useRef(null);
  useEffect(() => {
    const key = `${phase}-${round}-${revote}`;
    if (last.current === key || !TEXT[phase]) return;
    last.current = key;
    const t = TEXT[phase];
    setShow(revote && phase === "voting" ? ["REVOTE!", "It's a tie — vote again"] : phase === "reveal" ? [`ROUND ${round}`, t[1]] : t);
    sfx.reveal();
    const tm = setTimeout(() => setShow(null), 1700);
    return () => clearTimeout(tm);
  }, [phase, round, revote]);

  if (!show) return null;
  return (
    <div className="fixed inset-0 z-[70] grid place-items-center pointer-events-none bg-black/50 backdrop-blur-[2px] anim-screen">
      <div className="w-full py-8 bg-gradient-to-r from-transparent via-violet-700/70 to-transparent text-center border-y border-violet-400/40 anim-pop">
        <div className="logo glitch text-5xl sm:text-7xl" data-text={show[0]}>{show[0]}</div>
        <div className="font-display tracking-[.35em] text-xs sm:text-sm mt-3 text-sky-200">{show[1].toUpperCase()}</div>
      </div>
    </div>
  );
}
