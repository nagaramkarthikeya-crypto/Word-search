"use client";
import { sfx } from "@/utils/sfx";

// Every game button: neon clipped shape + click sound + haptic.
export default function GameButton({ variant = "", size = "", className = "", onClick, children, sound = "click", ...rest }) {
  return (
    <button
      {...rest}
      onMouseEnter={() => sfx.hover()}
      onClick={(e) => {
        if (rest.disabled) return;
        sfx[sound]?.();
        onClick?.(e);
      }}
      className={`btn-game ${variant} ${size} ${className}`}>
      {children}
    </button>
  );
}
