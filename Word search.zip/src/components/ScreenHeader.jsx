"use client";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { sfx } from "@/utils/sfx";

export default function ScreenHeader({ title, kicker, onBack, right }) {
  const router = useRouter();
  return (
    <div className="flex items-center gap-3 mb-6 anim-screen">
      <button onClick={() => { sfx.back(); onBack ? onBack() : router.push("/"); }}
        className="glass !rounded-xl w-11 h-11 grid place-items-center hover:bg-white/10 shrink-0" aria-label="Back">
        <ArrowLeft size={20} />
      </button>
      <div className="min-w-0 flex-1">
        {kicker && <div className="label">{kicker}</div>}
        <h1 className="title-xl text-2xl sm:text-3xl text-neon truncate">{title}</h1>
      </div>
      {right}
    </div>
  );
}
