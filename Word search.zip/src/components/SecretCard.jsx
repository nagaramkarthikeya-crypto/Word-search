"use client";
import { useEffect, useRef, useState } from "react";
import { Fingerprint, EyeOff } from "lucide-react";
import { wordLabel, CATEGORIES } from "@/utils/wordCategories";
import { sfx, haptic } from "@/utils/sfx";

// Hold-to-reveal secret card. Only this player's own secret is ever passed in.
export default function SecretCard({ secret, small = false }) {
  const [held, setHeld] = useState(false);
  const [progress, setProgress] = useState(0);
  const raf = useRef(null);
  const start = useRef(0);
  const revealed = progress >= 1 && held;
  const cat = CATEGORIES.find((c) => c.id === secret?.category);

  function down(e) {
    e.preventDefault();
    setHeld(true);
    start.current = performance.now();
    haptic(10);
    const loop = (t) => {
      const p = Math.min(1, (t - start.current) / 450);
      setProgress(p);
      if (p < 1) raf.current = requestAnimationFrame(loop);
      else secret?.isSpy ? sfx.spy() : sfx.reveal();
    };
    raf.current = requestAnimationFrame(loop);
  }
  function up() {
    cancelAnimationFrame(raf.current);
    setHeld(false);
    setProgress(0);
  }
  useEffect(() => () => cancelAnimationFrame(raf.current), []);

  if (!secret) return null;
  const h = small ? "h-56" : "h-80 sm:h-96";

  return (
    <div className="flex flex-col items-center gap-3 w-full">
      <div className={`card-3d w-full max-w-xs ${h} select-none touch-none cursor-pointer`}
        onPointerDown={down} onPointerUp={up} onPointerLeave={up} onPointerCancel={up} onContextMenu={(e) => e.preventDefault()}>
        <div className={`card-inner ${revealed ? "flipped" : ""}`}>
          {/* FRONT */}
          <div className="card-face glass glass-edge card-pattern flex flex-col items-center justify-center gap-4">
            <div className="absolute top-4 left-4 right-4 flex justify-between label !text-[9px]"><span>Classified</span><span>#SW-{new Date().getFullYear()}</span></div>
            <div className="relative w-24 h-24 grid place-items-center">
              <svg className="absolute inset-0 -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="45" stroke="rgba(255,255,255,.1)" strokeWidth="5" fill="none" />
                <circle cx="50" cy="50" r="45" stroke="#38bdf8" strokeWidth="5" fill="none" strokeLinecap="round"
                  strokeDasharray={283} strokeDashoffset={283 * (1 - progress)} style={{ filter: "drop-shadow(0 0 6px #38bdf8)" }} />
              </svg>
              <Fingerprint size={52} className={`text-violet-300 ${held ? "" : "anim-glow"}`} />
            </div>
            <div className="font-display tracking-[.3em] text-sm">HOLD TO REVEAL</div>
            <div className="text-[var(--muted)] text-sm font-semibold px-6 text-center">Cover your screen. Release to hide.</div>
            <div className="absolute bottom-4 font-display text-xl font-black tracking-[.4em] text-rose-400/80 border-2 border-rose-400/60 px-3 py-1 rotate-[-8deg]">TOP SECRET</div>
          </div>
          {/* BACK */}
          <div className={`card-face card-back flex flex-col items-center justify-center gap-3 p-6 text-center border ${secret.isSpy ? "bg-gradient-to-br from-rose-700/90 via-fuchsia-900/90 to-black border-rose-400/60 shadow-[0_0_60px_rgba(251,79,110,.6)]" : "bg-gradient-to-br from-violet-700/90 via-indigo-800/90 to-sky-700/80 border-sky-300/50 shadow-[0_0_60px_rgba(168,85,247,.6)]"}`}>
            {secret.isSpy ? (
              <>
                <div className="text-7xl">🕵️</div>
                <div className="font-display text-3xl font-black tracking-widest text-white drop-shadow-[0_0_14px_#fb4f6e]">YOU ARE<br />THE SPY</div>
                <div className="text-rose-100/90 font-semibold">Blend in. Listen to the clues and guess the word.</div>
                {cat && <span className="chip !bg-black/30">Category: {cat.icon} {cat.label}</span>}
              </>
            ) : (
              <>
                <div className="label !text-sky-100">Your secret word</div>
                <div className="font-display text-3xl sm:text-4xl font-black break-words text-white drop-shadow-[0_0_14px_#38bdf8]">{wordLabel(secret.word)}</div>
                {cat && <span className="chip !bg-black/30">{cat.icon} {cat.label}</span>}
                <div className="text-sky-100/90 font-semibold">Give clues — but don&apos;t make it too easy for the Spy.</div>
              </>
            )}
          </div>
        </div>
      </div>
      {!small && <div className="flex items-center gap-2 text-[var(--muted)] text-sm font-semibold"><EyeOff size={14} /> Only you can see this card</div>}
    </div>
  );
}
