"use client";
import { Bot, LogOut, Play, Users } from "lucide-react";
import RoomCode from "./RoomCode";
import PlayerCard from "./PlayerCard";
import GameButton from "./GameButton";
import Reactions from "./Reactions";
import { useToast } from "./Toast";
import { CATEGORIES } from "@/utils/wordCategories";
import { DURATIONS, TIE_RULES, MIN_PLAYERS } from "@/utils/gameConstants";
import { addBot, kickPlayer } from "@/services/roomService";
import { startGame } from "@/services/gameService";

export default function GameLobby({ room, me, isHost, onLeave }) {
  const toast = useToast();
  const players = room.order.map((id) => room.players[id]).filter(Boolean);
  const need = Math.max(0, MIN_PLAYERS - players.length);
  const cat = CATEGORIES.find((c) => c.id === room.settings.category);
  const slots = Array.from({ length: room.settings.maxPlayers - players.length });

  const act = (fn) => { try { fn(); } catch (e) { toast(e.message, "error"); } };

  return (
    <div className="grid lg:grid-cols-[1fr_340px] gap-5">
      <div className="flex flex-col gap-5">
        <div className="glass p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="label flex items-center gap-2"><Users size={14} /> Agents {players.length}/{room.settings.maxPlayers}</div>
            {need > 0
              ? <span className="chip anim-glow">Waiting for {need} more…</span>
              : <span className="chip !bg-emerald-500/20 !border-emerald-400/40">Ready to start</span>}
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 stagger">
            {players.map((p) => (
              <PlayerCard key={p.id} player={p} isHost={p.id === room.hostId} isMe={p.id === me}
                onKick={isHost && p.id !== me ? () => act(() => kickPlayer(room.code, p.id)) : null} />
            ))}
            {slots.map((_, i) => (
              <div key={`s${i}`} className="rounded-[22px] border-2 border-dashed border-white/10 grid place-items-center min-h-[128px] text-[var(--muted)]">
                <div className="text-center">
                  <div className="text-2xl opacity-40 anim-glow">?</div>
                  <div className="label !text-[9px]">Open slot</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <Reactions room={room} />
      </div>

      <div className="flex flex-col gap-4">
        <RoomCode code={room.code} />

        <div className="glass p-5">
          <div className="label mb-3">Mission settings</div>
          <div className="flex flex-wrap gap-2">
            <span className="chip">{cat?.icon} {cat?.label}</span>
            <span className="chip">{room.settings.lang === "te" ? "తెలుగు" : "English"}</span>
            <span className="chip">⏱ {DURATIONS[room.settings.duration]?.label}</span>
            <span className="chip">⚖ {TIE_RULES[room.settings.tieRule]?.label}</span>
            {room.round > 0 && <span className="chip">Round {room.round + 1}</span>}
          </div>
        </div>

        {isHost ? (
          <div className="flex flex-col gap-2">
            <GameButton onClick={() => act(() => startGame(room.code))} disabled={need > 0} className="w-full !py-5 text-lg">
              <Play /> {need > 0 ? `Need ${need} more` : "Start Game"}
            </GameButton>
            <GameButton variant="secondary" size="sm" className="w-full" onClick={() => act(() => addBot(room.code))}
              disabled={players.length >= room.settings.maxPlayers}>
              <Bot size={15} /> Add test bot
            </GameButton>
          </div>
        ) : (
          <div className="glass p-5 text-center">
            <div className="text-3xl anim-float">⏳</div>
            <div className="font-display tracking-widest text-sm mt-2">Waiting for host</div>
            <div className="text-[var(--muted)] font-semibold">{room.players[room.hostId]?.name} will start the game</div>
          </div>
        )}

        <GameButton variant="ghost" size="sm" className="w-full" sound="back" onClick={onLeave}><LogOut size={15} /> Leave room</GameButton>

        <div className="glass p-4 max-h-52 overflow-y-auto scroll-thin">
          <div className="label mb-2">Activity</div>
          {[...(room.feed || [])].reverse().slice(0, 12).map((f, i) => (
            <div key={i} className="text-sm font-semibold text-[var(--muted)] py-1 border-b border-white/5 last:border-0">
              <span className="text-violet-300">›</span> {f.text}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
