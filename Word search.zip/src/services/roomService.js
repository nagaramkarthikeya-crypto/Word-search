// Room operations. The UI only talks to these functions.
// Phase 2: backed by the local demo engine. Phase 3-4: same signatures, Firestore + Cloud Functions.
import * as E from "./localEngine";
import { getPlayerId, saveProfile, validateNickname } from "./playerService";
import { MAX_PLAYERS, MIN_PLAYERS, PHASES } from "@/utils/gameConstants";

export function createRoom({ name, avatar, maxPlayers, category, lang, duration, tieRule, customWords }) {
  const err = validateNickname(name);
  if (err) throw new Error(err);
  if (category === "custom" && (customWords || []).filter((w) => w.trim()).length < 3) {
    throw new Error("Add at least 3 custom words");
  }
  E.cleanupExpired();
  const pid = getPlayerId();
  saveProfile({ name, avatar });
  const code = E.generateCode();
  const settings = {
    maxPlayers: Math.min(MAX_PLAYERS, Math.max(MIN_PLAYERS, Number(maxPlayers) || 8)),
    category, lang: lang || "en", duration: duration || "normal", tieRule: tieRule || "revote",
    customWords: (customWords || []).map((w) => w.trim()).filter(Boolean).slice(0, 100),
  };
  E._write(code, E.createRoomState({ code, hostId: pid, name: name.trim(), avatar, settings }));
  return code;
}

export function checkRoom(code) {
  const s = E.read(String(code || "").toUpperCase());
  if (!s || s.expiresAt < Date.now()) return { ok: false, reason: "Room not found or expired" };
  const count = s.order.filter((id) => s.players[id]).length;
  if (s.players[getPlayerId()]) return { ok: true, rejoin: true, room: s };
  if (s.phase !== PHASES.LOBBY) return { ok: false, reason: "Game already in progress" };
  if (count >= s.settings.maxPlayers) return { ok: false, reason: "Room is full" };
  return { ok: true, room: s, count };
}

export function joinRoom({ code, name, avatar }) {
  code = String(code || "").toUpperCase().trim();
  const err = validateNickname(name);
  if (err) throw new Error(err);
  const pid = getPlayerId();
  saveProfile({ name, avatar });
  const check = checkRoom(code);
  if (!check.ok) throw new Error(check.reason);
  E.mutate(code, (s) => {
    if (s.kicked?.includes(pid)) throw new Error("You were removed from this room");
    if (s.players[pid]) {
      s.players[pid].lastSeen = Date.now(); // reconnection
      return;
    }
    const taken = Object.values(s.players).some((p) => p.name.toLowerCase() === name.trim().toLowerCase());
    if (taken) throw new Error("That nickname is already in this room");
    if (s.order.filter((id) => s.players[id]).length >= s.settings.maxPlayers) throw new Error("Room is full");
    s.players[pid] = E.newPlayer(pid, name.trim(), avatar);
    s.order.push(pid);
    E._feed(s, `${name.trim()} joined`);
  });
  return code;
}

export function leaveRoom(code) {
  const pid = getPlayerId();
  const s = E.read(code);
  if (!s) return;
  const remaining = s.order.filter((id) => id !== pid && s.players[id] && !s.players[id].isBot);
  if (!remaining.length) return E._write(code, null); // last human leaves -> delete room
  E.mutate(code, (st) => {
    const name = st.players[pid]?.name;
    delete st.players[pid];
    st.order = st.order.filter((id) => id !== pid);
    if (name) E._feed(st, `${name} left`);
    if (st.hostId === pid) {
      st.hostId = st.order.find((id) => st.players[id] && !st.players[id].isBot);
      E._feed(st, `${st.players[st.hostId]?.name} is the new host`);
    }
    if (st.phase !== PHASES.LOBBY && pid === st.game.spyId) {
      E.backToLobby(st);
      E._feed(st, "The Spy left — round cancelled");
    }
  });
}

export function kickPlayer(code, targetId) {
  const pid = getPlayerId();
  E.mutate(code, (s) => {
    if (s.hostId !== pid) throw new Error("Only the host can do that");
    if (s.phase !== PHASES.LOBBY) throw new Error("Only in the lobby");
    const name = s.players[targetId]?.name;
    const wasBot = s.players[targetId]?.isBot;
    delete s.players[targetId];
    s.order = s.order.filter((id) => id !== targetId);
    if (!wasBot) s.kicked = [...(s.kicked || []), targetId];
    E._feed(s, `${name} was removed`);
  });
}

export function addBot(code) {
  const pid = getPlayerId();
  E.mutate(code, (s) => {
    if (s.hostId !== pid) throw new Error("Only the host can add bots");
    if (s.order.filter((id) => s.players[id]).length >= s.settings.maxPlayers) throw new Error("Room is full");
    E.addBot(s);
  });
}

export function sendReaction(code, emoji) {
  const pid = getPlayerId();
  E.mutate(code, (s) => {
    if (!s.players[pid]) return;
    s.reactions = [...(s.reactions || []), { pid, emoji, at: Date.now(), id: Math.random().toString(36).slice(2) }].slice(-15);
  });
}

export function heartbeat(code) {
  const pid = getPlayerId();
  const s = E.read(code);
  if (!s || !s.players[pid]) return;
  E.mutate(code, (st) => {
    if (st.players[pid]) st.players[pid].lastSeen = Date.now();
    E.migrateHostIfNeeded(st);
  });
}

export const subscribeRoom = E.subscribe;
export const getOnlineCount = E.onlineCount;
export const cleanupExpiredRooms = E.cleanupExpired;
export const inviteLink = (code) =>
  typeof window === "undefined" ? "" : `${window.location.origin}/join-room?code=${code}`;
