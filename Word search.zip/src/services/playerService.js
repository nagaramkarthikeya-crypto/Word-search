// Player identity, profile and personal stats.
// Phase 2: identity is per browser TAB (sessionStorage) so you can open several tabs
// and play as several people on one laptop. Phase 3 swaps this for Firebase Anonymous Auth uid.
import { AVATARS } from "@/utils/gameConstants";

const isBrowser = () => typeof window !== "undefined";

export function getPlayerId() {
  if (!isBrowser()) return null;
  let id = sessionStorage.getItem("sw_pid");
  if (!id) {
    id = "p_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
    sessionStorage.setItem("sw_pid", id);
  }
  return id;
}

export function getProfile() {
  if (!isBrowser()) return { name: "", avatar: 0 };
  try {
    const p = JSON.parse(sessionStorage.getItem("sw_profile") || localStorage.getItem("sw_profile") || "null");
    if (p) return p;
  } catch {}
  return { name: "", avatar: Math.floor(Math.random() * AVATARS.length) };
}

export function saveProfile(profile) {
  if (!isBrowser()) return;
  const clean = { name: String(profile.name || "").trim().slice(0, 16), avatar: Number(profile.avatar) || 0 };
  sessionStorage.setItem("sw_profile", JSON.stringify(clean));
  localStorage.setItem("sw_profile", JSON.stringify(clean));
  return clean;
}

export function validateNickname(name) {
  const n = String(name || "").trim();
  if (n.length < 2) return "Nickname needs at least 2 characters";
  if (n.length > 16) return "Max 16 characters";
  if (!/^[\p{L}\p{N} _.-]+$/u.test(n)) return "Letters, numbers, space, _ . - only";
  return null;
}

// ---- Personal history & stats (this device) ----
export function getHistory() {
  if (!isBrowser()) return [];
  try {
    return JSON.parse(localStorage.getItem("sw_history") || "[]");
  } catch {
    return [];
  }
}

export function recordHistory(entry) {
  if (!isBrowser()) return;
  const list = getHistory();
  if (list.some((h) => h.id === entry.id)) return;
  list.unshift(entry);
  localStorage.setItem("sw_history", JSON.stringify(list.slice(0, 50)));
}

export function getMyStats() {
  const h = getHistory();
  const s = { games: h.length, wins: 0, spyGames: 0, spyWins: 0, groupWins: 0, correctGuesses: 0 };
  for (const g of h) {
    if (g.won) s.wins++;
    if (g.wasSpy) s.spyGames++;
    if (g.wasSpy && g.won) s.spyWins++;
    if (!g.wasSpy && g.won) s.groupWins++;
    if (g.wasSpy && g.guessedRight) s.correctGuesses++;
  }
  return s;
}

export function getCustomCategories() {
  if (!isBrowser()) return [];
  try {
    return JSON.parse(localStorage.getItem("sw_custom_words") || "[]");
  } catch {
    return [];
  }
}
export function saveCustomCategories(words) {
  if (isBrowser()) localStorage.setItem("sw_custom_words", JSON.stringify(words));
}
