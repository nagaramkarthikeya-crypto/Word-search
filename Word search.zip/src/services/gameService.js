// Game actions. Phase 2: local engine. Phase 5-6: these become callable Cloud Functions
// (startGame, submitClue, castVote, spyGuess...) so clients can never cheat.
import * as E from "./localEngine";
import { getPlayerId } from "./playerService";
import { PHASES } from "@/utils/gameConstants";

const me = () => getPlayerId();
const hostOnly = (s) => {
  if (s.hostId !== me()) throw new Error("Only the host can do that");
};

export const startGame = (code) => E.mutate(code, (s) => { hostOnly(s); E.startGame(s); });
export const markReady = (code) => E.mutate(code, (s) => { s.game.ready[me()] = true; });
export const submitClue = (code, text) => E.mutate(code, (s) => E.submitClue(s, me(), text));
export const castVote = (code, targetId) => E.mutate(code, (s) => E.castVote(s, me(), targetId));
export const submitSpyGuess = (code, guess) => E.mutate(code, (s) => E.spyGuess(s, me(), guess));
export const playAgain = (code) => E.mutate(code, (s) => { hostOnly(s); E.backToLobby(s); });

// Host controls
export const hostSkipTurn = (code) =>
  E.mutate(code, (s) => {
    hostOnly(s);
    if (s.phase === PHASES.REVEAL) {
      s.phaseEndsAt = 1;
      E.tick(s);
      return;
    }
    if (s.phase !== PHASES.CLUES) return;
    s.game.clues.push({ pid: s.game.turnOrder[s.game.turnIndex], text: "— skipped by host —", at: Date.now(), skipped: true });
    E.nextTurn(s);
  });

export const hostStartVoting = (code) =>
  E.mutate(code, (s) => {
    hostOnly(s);
    if (s.phase === PHASES.REVEAL || s.phase === PHASES.CLUES) E.beginVoting(s);
  });

export const hostEndVoting = (code) =>
  E.mutate(code, (s) => {
    hostOnly(s);
    if (s.phase === PHASES.VOTING) E.resolveVotes(s);
  });

// Called every second by the host's tab
export function hostTick(code) {
  const s = E.read(code);
  if (!s || s.hostId !== me()) return;
  const copy = JSON.parse(JSON.stringify(s));
  if (E.tick(copy)) E.mutate(code, (st) => Object.assign(st, copy));
}

// What THIS player is allowed to know (mirrors the Firestore privatePlayerData doc)
export function getMySecret(room) {
  if (!room || room.phase === PHASES.LOBBY || !room.game?.spyId) return null;
  const pid = me();
  if (!room.players[pid]) return null;
  if (room.game.spyId === pid) return { isSpy: true, category: room.game.category };
  return { isSpy: false, word: room.game.word, category: room.game.category };
}
