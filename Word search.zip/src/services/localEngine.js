// =====================================================================
// LOCAL DEMO ENGINE (Phase 2)
// Runs the full game in the browser: localStorage = "database",
// BroadcastChannel = "realtime". Open several tabs to play as several
// players, or add bots. Phase 3-6 replaces this with Firestore + Cloud
// Functions behind the SAME service functions (roomService / gameService),
// so the UI does not change.
// NOTE: in this local mode the secret lives in browser storage. That is fine
// for UI testing only; the Firebase version keeps it server-side.
// =====================================================================
import {
  PHASES, DURATIONS, ROOM_TTL_MS, OFFLINE_AFTER_MS, MIN_PLAYERS, AVATARS, BOT_NAMES,
} from "@/utils/gameConstants";
import { getWordBank, BOT_HINTS, pickRandom, isCorrectGuess, categoryOfWord } from "@/utils/wordCategories";

const KEY = (code) => `sw_room_${code}`;
const listeners = new Set();
let channel = null;

function getChannel() {
  if (typeof window === "undefined") return null;
  if (!channel && "BroadcastChannel" in window) {
    channel = new BroadcastChannel("secret-word");
    channel.onmessage = (e) => listeners.forEach((fn) => fn(e.data?.code));
  }
  return channel;
}

if (typeof window !== "undefined") {
  window.addEventListener("storage", (e) => {
    if (e.key && e.key.startsWith("sw_room_")) listeners.forEach((fn) => fn(e.key.slice(8)));
  });
}

export function read(code) {
  try {
    return JSON.parse(localStorage.getItem(KEY(code)) || "null");
  } catch {
    return null;
  }
}

function write(code, state) {
  if (state === null) localStorage.removeItem(KEY(code));
  else localStorage.setItem(KEY(code), JSON.stringify(state));
  getChannel()?.postMessage({ code });
  listeners.forEach((fn) => fn(code));
}

// Atomic-ish update (single-threaded per tab; good enough for a local demo)
export function mutate(code, fn) {
  const s = read(code);
  if (!s) throw new Error("Room not found");
  const res = fn(s);
  s.updatedAt = Date.now();
  s.expiresAt = Date.now() + ROOM_TTL_MS;
  write(code, s);
  return res;
}

export function subscribe(code, cb) {
  getChannel();
  const fn = (c) => {
    if (c === code) cb(read(code));
  };
  listeners.add(fn);
  cb(read(code));
  return () => listeners.delete(fn);
}

export function generateCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/1/I confusion
  let code;
  do {
    code = Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
  } while (read(code));
  return code;
}

export function cleanupExpired() {
  if (typeof window === "undefined") return;
  const now = Date.now();
  for (let i = localStorage.length - 1; i >= 0; i--) {
    const k = localStorage.key(i);
    if (!k?.startsWith("sw_room_")) continue;
    try {
      const s = JSON.parse(localStorage.getItem(k));
      if (!s || s.expiresAt < now) localStorage.removeItem(k);
    } catch {
      localStorage.removeItem(k);
    }
  }
}

export function onlineCount() {
  if (typeof window === "undefined") return 0;
  const now = Date.now();
  let n = 0;
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (!k?.startsWith("sw_room_")) continue;
    try {
      const s = JSON.parse(localStorage.getItem(k));
      Object.values(s.players || {}).forEach((p) => {
        if (p.isBot || now - p.lastSeen < OFFLINE_AFTER_MS) n++;
      });
    } catch {}
  }
  return n;
}

// ----------------------------------------------------------------------
export const isOnline = (p, now = Date.now()) => p.isBot || now - (p.lastSeen || 0) < OFFLINE_AFTER_MS;

export function newPlayer(id, name, avatar, isBot = false) {
  return { id, name, avatar, isBot, joinedAt: Date.now(), lastSeen: Date.now() };
}

export function freshGame() {
  return {
    spyId: null, word: null, category: null,
    turnOrder: [], turnIndex: 0, turnStartedAt: 0, clues: [],
    votes: {}, candidates: [], revoteCount: 0, tally: {},
    accusedId: null, spyGuess: null, guessedRight: false,
    outcome: null, ready: {}, scored: false,
  };
}

export function createRoomState({ code, hostId, name, avatar, settings }) {
  const now = Date.now();
  return {
    code, hostId, createdAt: now, updatedAt: now, expiresAt: now + ROOM_TTL_MS,
    settings, phase: PHASES.LOBBY, phaseEndsAt: 0, round: 0,
    players: { [hostId]: newPlayer(hostId, name, avatar) },
    order: [hostId], kicked: [],
    game: freshGame(),
    scores: {}, reactions: [], feed: [{ at: now, text: `${name} created the room` }],
    history: [],
  };
}

function feed(s, text) {
  s.feed = [...(s.feed || []), { at: Date.now(), text }].slice(-30);
}

export function addBot(s) {
  const used = new Set(Object.values(s.players).map((p) => p.name.toLowerCase()));
  const name = BOT_NAMES.find((n) => !used.has(`${n} bot`.toLowerCase())) || "Bot";
  const id = "bot_" + Math.random().toString(36).slice(2, 8);
  s.players[id] = newPlayer(id, `${name} Bot`, Math.floor(Math.random() * AVATARS.length), true);
  s.order.push(id);
  feed(s, `${name} Bot joined`);
}

// ---------------- Game flow (authority = host tab) ----------------
const activeIds = (s) => s.order.filter((id) => s.players[id]);

export function startGame(s) {
  const ids = activeIds(s);
  if (ids.length < MIN_PLAYERS) throw new Error(`Need at least ${MIN_PLAYERS} players`);
  const bank = getWordBank(s.settings.category, s.settings.lang, s.settings.customWords);
  if (!bank.length) throw new Error("Word list is empty");
  const d = DURATIONS[s.settings.duration] || DURATIONS.normal;
  const word = pickRandom(bank);
  s.round += 1;
  s.game = freshGame();
  s.game.spyId = pickRandom(ids);
  s.game.word = word;
  s.game.category = s.settings.category === "random" ? categoryOfWord(word, s.settings.lang) : s.settings.category;
  s.game.turnOrder = [...ids].sort(() => Math.random() - 0.5);
  s.phase = PHASES.REVEAL;
  s.phaseEndsAt = Date.now() + d.reveal * 1000;
  s.reactions = [];
  feed(s, `Round ${s.round} started — check your secret card!`);
}

function beginClues(s) {
  const d = DURATIONS[s.settings.duration] || DURATIONS.normal;
  s.phase = PHASES.CLUES;
  s.game.turnIndex = 0;
  s.game.turnStartedAt = Date.now();
  s.phaseEndsAt = Date.now() + d.clue * 1000;
  skipOfflineTurns(s);
}

function skipOfflineTurns(s) {
  const now = Date.now();
  while (s.game.turnIndex < s.game.turnOrder.length) {
    const p = s.players[s.game.turnOrder[s.game.turnIndex]];
    if (p && isOnline(p, now)) return;
    s.game.clues.push({ pid: s.game.turnOrder[s.game.turnIndex], text: "— offline —", at: now, skipped: true });
    s.game.turnIndex++;
  }
  if (s.game.turnIndex >= s.game.turnOrder.length) beginVoting(s);
}

export function nextTurn(s) {
  const d = DURATIONS[s.settings.duration] || DURATIONS.normal;
  s.game.turnIndex++;
  s.game.turnStartedAt = Date.now();
  s.phaseEndsAt = Date.now() + d.clue * 1000;
  if (s.game.turnIndex >= s.game.turnOrder.length) return beginVoting(s);
  skipOfflineTurns(s);
}

export function submitClue(s, pid, text) {
  if (s.phase !== PHASES.CLUES) throw new Error("Not clue time");
  if (s.game.turnOrder[s.game.turnIndex] !== pid) throw new Error("Not your turn");
  const clean = String(text || "").trim().slice(0, 40);
  if (!clean) throw new Error("Type a clue");
  if (s.game.word && isCorrectGuess(s.game.word, clean)) throw new Error("You can't say the secret word!");
  s.game.clues.push({ pid, text: clean, at: Date.now() });
  nextTurn(s);
}

export function beginVoting(s, candidates = null) {
  const d = DURATIONS[s.settings.duration] || DURATIONS.normal;
  s.phase = PHASES.VOTING;
  s.game.votes = {};
  s.game.candidates = candidates || activeIds(s);
  s.phaseEndsAt = Date.now() + d.vote * 1000;
}

export function castVote(s, voterId, targetId) {
  if (s.phase !== PHASES.VOTING) throw new Error("Voting is closed");
  if (!s.players[voterId]) throw new Error("You are not in this room");
  if (s.game.votes[voterId]) throw new Error("You already voted");
  if (voterId === targetId) throw new Error("You can't vote for yourself");
  if (!s.game.candidates.includes(targetId)) throw new Error("Invalid choice");
  s.game.votes[voterId] = targetId;
}

function eligibleVoters(s) {
  const now = Date.now();
  return activeIds(s).filter((id) => isOnline(s.players[id], now));
}

export function resolveVotes(s) {
  const d = DURATIONS[s.settings.duration] || DURATIONS.normal;
  const tally = {};
  Object.values(s.game.votes).forEach((t) => (tally[t] = (tally[t] || 0) + 1));
  s.game.tally = tally;
  const max = Math.max(0, ...Object.values(tally));
  const top = Object.keys(tally).filter((k) => tally[k] === max);

  if (max === 0 || top.length > 1) {
    if (s.settings.tieRule === "revote" && s.game.revoteCount < 1 && top.length > 1) {
      s.game.revoteCount++;
      feed(s, "It's a tie! Revote between the tied players.");
      return beginVoting(s, top);
    }
    s.game.accusedId = null;
    return finish(s, "spy", "No majority — the Spy slipped away");
  }
  s.game.accusedId = top[0];
  if (top[0] === s.game.spyId) {
    s.phase = PHASES.SPY_GUESS;
    s.game.guessStartedAt = Date.now();
    s.phaseEndsAt = Date.now() + d.guess * 1000;
    feed(s, `${s.players[top[0]]?.name} was caught! One last chance to guess the word...`);
  } else {
    finish(s, "spy", `${s.players[top[0]]?.name || "An innocent"} was innocent — the Spy wins`);
  }
}

export function spyGuess(s, pid, guess) {
  if (s.phase !== PHASES.SPY_GUESS) throw new Error("Not guessing time");
  if (pid !== s.game.spyId) throw new Error("Only the Spy can guess");
  s.game.spyGuess = String(guess || "").trim().slice(0, 40);
  s.game.guessedRight = isCorrectGuess(s.game.word, s.game.spyGuess);
  if (s.game.guessedRight) finish(s, "spy", "The Spy was caught but guessed the word!");
  else finish(s, "group", "The group caught the Spy!");
}

function finish(s, winner, reason) {
  s.phase = PHASES.RESULTS;
  s.phaseEndsAt = 0;
  s.game.outcome = { winner, reason };
  if (!s.game.scored) {
    s.game.scored = true;
    for (const id of activeIds(s)) {
      const p = s.players[id];
      const sc = (s.scores[id] ||= { name: p.name, avatar: p.avatar, isBot: p.isBot, wins: 0, spyWins: 0, groupWins: 0, correctGuesses: 0, games: 0, points: 0 });
      sc.name = p.name;
      sc.games++;
      const isSpy = id === s.game.spyId;
      const won = (winner === "spy") === isSpy;
      if (won) {
        sc.wins++;
        if (isSpy) sc.spyWins++;
        else sc.groupWins++;
        sc.points += isSpy ? 3 : 1;
      }
      if (isSpy && s.game.guessedRight) {
        sc.correctGuesses++;
        sc.points += 1;
      }
      // voted for the spy = detective bonus
      if (!isSpy && s.game.votes[id] === s.game.spyId) sc.points += 1;
    }
    s.history = [
      ...(s.history || []),
      {
        round: s.round, word: s.game.word, spyId: s.game.spyId, spyName: s.players[s.game.spyId]?.name,
        winner, reason, clues: s.game.clues, votes: s.game.votes, tally: s.game.tally, guess: s.game.spyGuess,
        guessedRight: s.game.guessedRight, at: Date.now(),
      },
    ].slice(-20);
  }
  feed(s, reason);
}

export function backToLobby(s) {
  s.phase = PHASES.LOBBY;
  s.phaseEndsAt = 0;
  s.game = freshGame();
  s.reactions = [];
  feed(s, "Back in the lobby — get ready for another round");
}

export function migrateHostIfNeeded(s) {
  const host = s.players[s.hostId];
  if (host && !host.isBot && isOnline(host)) return false;
  const next = s.order.find((id) => s.players[id] && !s.players[id].isBot && isOnline(s.players[id]));
  if (next && next !== s.hostId) {
    s.hostId = next;
    feed(s, `${s.players[next].name} is the new host`);
    return true;
  }
  return false;
}

// The host's tab drives timers & bots. Returns true if state changed.
export function tick(s, now = Date.now()) {
  let changed = false;
  const g = s.game;
  const ends = s.phaseEndsAt && now >= s.phaseEndsAt;

  if (s.phase === PHASES.REVEAL) {
    const humans = activeIds(s).filter((id) => !s.players[id].isBot && isOnline(s.players[id], now));
    const allReady = humans.length > 0 && humans.every((id) => g.ready[id]);
    if (ends || allReady) {
      beginClues(s);
      changed = true;
    }
  } else if (s.phase === PHASES.CLUES) {
    const cur = s.players[g.turnOrder[g.turnIndex]];
    if (cur?.isBot && now - g.turnStartedAt > 2200) {
      const pool = BOT_HINTS[g.category] || BOT_HINTS.custom;
      const used = new Set(g.clues.map((c) => c.text));
      const text = pool.find((h) => !used.has(h) && Math.random() > 0.3) || pickRandom(pool);
      g.clues.push({ pid: cur.id, text, at: now });
      nextTurn(s);
      changed = true;
    } else if (ends) {
      g.clues.push({ pid: g.turnOrder[g.turnIndex], text: "— time out —", at: now, skipped: true });
      nextTurn(s);
      changed = true;
    } else if (cur && !isOnline(cur, now)) {
      skipOfflineTurns(s);
      changed = true;
    }
  } else if (s.phase === PHASES.VOTING) {
    for (const id of activeIds(s)) {
      const p = s.players[id];
      if (p.isBot && !g.votes[id] && Math.random() < 0.25) {
        const opts = g.candidates.filter((c) => c !== id);
        if (opts.length) {
          // bots lean towards the spy a little so games feel real
          g.votes[id] = Math.random() < 0.35 && g.spyId !== id && opts.includes(g.spyId) ? g.spyId : pickRandom(opts);
          changed = true;
        }
      }
    }
    const voters = eligibleVoters(s);
    const allVoted = voters.every((id) => g.votes[id] || !g.candidates.some((c) => c !== id));
    if (ends || allVoted) {
      resolveVotes(s);
      changed = true;
    }
  } else if (s.phase === PHASES.SPY_GUESS) {
    const spy = s.players[g.spyId];
    if (spy?.isBot && now - (g.guessStartedAt || 0) > 2500) {
      const bank = getWordBank(s.settings.category, s.settings.lang, s.settings.customWords);
      spyGuess(s, spy.id, Math.random() < 0.2 ? (typeof g.word === "string" ? g.word : g.word.r) : pickRandom(bank)?.r || pickRandom(bank));
      changed = true;
    } else if (ends || !spy || !isOnline(spy, now)) {
      s.game.spyGuess = s.game.spyGuess || "";
      finish(s, "group", "The Spy ran out of time — group wins!");
      changed = true;
    }
  }
  return changed;
}

export { write as _write, feed as _feed };
