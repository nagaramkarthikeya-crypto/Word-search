"use client";
import { Suspense, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { LogIn, CheckCircle2, XCircle } from "lucide-react";
import ScreenHeader from "@/components/ScreenHeader";
import ProfilePicker from "@/components/ProfilePicker";
import GameButton from "@/components/GameButton";
import Avatar from "@/components/Avatar";
import { useToast } from "@/components/Toast";
import { getProfile, validateNickname } from "@/services/playerService";
import { checkRoom, joinRoom } from "@/services/roomService";
import { sfx } from "@/utils/sfx";

function JoinInner() {
  const router = useRouter();
  const params = useSearchParams();
  const toast = useToast();
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState(0);
  const [code, setCode] = useState("");
  const [err, setErr] = useState(null);
  const [status, setStatus] = useState(null);
  const inputs = useRef([]);

  useEffect(() => {
    const p = getProfile();
    setName(p.name);
    setAvatar(p.avatar);
    const c = (params.get("code") || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6);
    if (c) setCode(c);
  }, [params]);

  useEffect(() => {
    if (code.length === 6) {
      const r = checkRoom(code);
      setStatus(r);
      r.ok ? sfx.join() : sfx.error();
    } else setStatus(null);
  }, [code]);

  function setChar(i, v) {
    const ch = v.toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (ch.length > 1) { // paste
      setCode(ch.slice(0, 6));
      inputs.current[Math.min(5, ch.length)]?.focus();
      return;
    }
    const next = ch ? (code.slice(0, i) + ch + code.slice(i + 1)).slice(0, 6) : code.slice(0, i) + code.slice(i + 1);
    setCode(next);
    if (ch) { sfx.tick(); inputs.current[i + 1]?.focus(); }
  }

  function submit() {
    const e = validateNickname(name);
    setErr(e);
    if (e) return sfx.error();
    if (code.length !== 6) return toast("Enter the 6-character room code", "error");
    try {
      const c = joinRoom({ code, name, avatar });
      sfx.join();
      router.push(`/lobby?code=${c}`);
    } catch (x) {
      toast(x.message, "error");
    }
  }

  const host = status?.room?.players?.[status.room.hostId];

  return (
    <div className="max-w-2xl mx-auto">
      <ScreenHeader kicker="Infiltrate" title="Join Room" />
      <div className="flex flex-col gap-4 stagger">
        <div className="glass glass-edge p-6 hud-frame">
          <span className="corner tl" /><span className="corner tr" /><span className="corner bl" /><span className="corner br" />
          <div className="label mb-4 text-center">Room code</div>
          <div className="flex justify-center gap-2 sm:gap-3">
            {Array.from({ length: 6 }, (_, i) => (
              <input key={i} ref={(el) => (inputs.current[i] = el)} value={code[i] || ""} inputMode="text" autoCapitalize="characters"
                onChange={(e) => setChar(i, e.target.value)}
                onKeyDown={(e) => { if (e.key === "Backspace" && !code[i] && i > 0) { inputs.current[i - 1]?.focus(); setCode(code.slice(0, i - 1)); } if (e.key === "Enter") submit(); }}
                className={`input-game !p-0 w-11 h-14 sm:w-14 sm:h-16 text-center font-display text-2xl sm:text-3xl font-black ${status && !status.ok ? "!border-rose-400" : status?.ok ? "!border-emerald-400" : ""}`} />
            ))}
          </div>
          <div className="h-12 mt-4 flex items-center justify-center">
            {status?.ok && (
              <div className="flex items-center gap-3 anim-pop text-emerald-300 font-bold">
                <CheckCircle2 /> {status.rejoin ? "Welcome back! Rejoin your room" : <>Room found · host {host && <Avatar index={host.avatar} size={26} />} {host?.name} · {status.count}/{status.room.settings.maxPlayers}</>}
              </div>
            )}
            {status && !status.ok && <div className="flex items-center gap-2 text-rose-300 font-bold anim-shake"><XCircle /> {status.reason}</div>}
          </div>
        </div>

        <div className="glass p-6">
          <ProfilePicker name={name} setName={(v) => { setName(v); setErr(null); }} avatar={avatar} setAvatar={setAvatar} error={err} />
        </div>

        <GameButton onClick={submit} disabled={!status?.ok} className="w-full text-lg !py-5" sound="">
          <LogIn /> Join Room
        </GameButton>
      </div>
    </div>
  );
}

export default function JoinRoom() {
  return <Suspense fallback={null}><JoinInner /></Suspense>;
}
