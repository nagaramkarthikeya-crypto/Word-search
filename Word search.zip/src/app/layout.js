import { Orbitron, Rajdhani } from "next/font/google";
import "./globals.css";
import GameShell from "@/components/GameShell";

const orbitron = Orbitron({ subsets: ["latin"], weight: ["500", "700", "800", "900"], variable: "--font-orbitron" });
const rajdhani = Rajdhani({ subsets: ["latin"], weight: ["400", "500", "600", "700"], variable: "--font-rajdhani" });

export const metadata = {
  title: "SECRET WORD — Trust No One. Find The Spy.",
  description: "Online multiplayer social deduction party game for 5–10 players.",
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#0d0620",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${orbitron.variable} ${rajdhani.variable}`} suppressHydrationWarning>
      <body className="antialiased">
        <GameShell>{children}</GameShell>
      </body>
    </html>
  );
}
