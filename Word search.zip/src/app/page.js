"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, LogIn, BookOpen, Sparkles, BarChart3, Pencil, ChevronRight } from "lucide-react";
import Avatar from "@/components/Avatar";
import Modal from "@/components/Modal";
import HowToPlay from "@/components/HowToPlay";
import { sfx } from "@/utils/sfx";
import { getProfile, saveProfile, getMyStats, getHistory } from "@/services/playerService";
import { cleanupExpiredRooms, getOnlineCount } from "@/services/roomService";
import { AVATARS } from "@/utils/gameConstants";
import { wordLabel } from "@/utils/wordCategories";

const TAGLINE = "TRUST NO ONE. FIND THE SPY.";

const FEATURES = [
  ["🔒", "Private rooms", "6-character codes, invite links & Web Share"],
  ["🕵️", "Hidden roles", "Secret cards only you can reveal — hold to peek"],
  ["⏱️", "Synced timers", "Every phone sees the same countdown"],
  ["🗳️", "Secret ballots", "Live vote status, choices hidden till the end"],
  ["🔁", "Fair tie-breaks", "Configurable revote for tied players"],
  ["🇮🇳", "Telugu + English", "Word banks in both, guess in either script"],
  ["✏️", "Custom words", "Make your own category for inside jokes"],
  ["🏆", "Scoreboard", "Wins, Spy wins, guesses, rankings & replay"],
  ["😂", "Reactions & SFX", "Emoji reactions, sound effects and haptics"],
];

export default function Home() {
  const router = useRouter();
  const [typed, setTyped] = useState("");
  const [profile, setProfile] = useState({ name: "", avatar: 0 });
  const [modal, setModal] = useState(null);
  const [online, setOnline] = useState(0);
  const [stats, setStats] = useState(null);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    cleanupExpiredRooms();
    setProfile(getProfile());
    setOnline(getOnlineCount());
    let i = 0;
    const t = setInterval(() => { i++; setTyped(TAGLINE.slice(0, i)); if (i >= TAGLINE.length) clearInterval(t); }, 55);
    return () => clearInterval(t);
  }, []);

  function go(path) { router.push(path); }
  function openStats() { setStats(getMyStats()); setHistory(getHistory()); setModal("stats"); }

  const menu = [
    { label: "Create Room", sub: "Host a private match", icon: Plus, onClick: () => go("/create-room"), primary: true },
    { label: "Join Room", sub: "Enter a 6-character code", icon: LogIn, onClick: () => go("/join-room") },
    { label: "How to Play", sub: "Mission briefing", icon: BookOpen, onClick: () => setModal("how") },
    { label: "Features", sub: "What's inside", icon: Sparkles, onClick: () => setModal("features") },
    { label: "My Stats", sub: "History & records", icon: BarChart3, onClick: openStats },
  ];

  return (
    <div className="grid lg:grid-cols-[1.1fr_.9fr] gap-8 lg:gap-12 items-center min-h-[calc(100dvh-140px)]">
      {/* Left: title + menu */}
      <section className="anim-screen">
        <div className="label mb-3 flex items-center gap-2"><span className="w-8 h-px bg-violet-400" /> Social deduction · 5–10 players</div>
        <h1 className="logo glitch text-[13vw] sm:text-7xl lg:text-8xl" data-text="SECRET">SECRET</h1>
        <h1 className="logo glitch text-[13vw] sm:text-7xl lg:text-8xl -mt-1" data-text="WORD">WORD</h1>
        <p className="font-display mt-4 text-sm sm:text-lg tracking-[.3em] text-sky-300 h-7">
          {typed}<span className="anim-blink">▌</span>
        </p>

        <div className="mt-8 flex flex-col gap-3 max-w-md stagger">
          {menu.map((m) => (
            <button key={m.label} onClick={() => { sfx.click(); m.onClick(); }} onMouseEnter={() => sfx.hover()}
              onMouseMove={(e) => { const r = e.currentTarget.getBoundingClientRect(); e.currentTarget.style.setProperty("--mx", `${e.clientX - r.left}px`); e.currentTarget.style.setProperty("--my", `${e.clientY - r.top}px`); }}
              className={`menu-tile glass flex items-center gap-4 px-5 py-4 ${m.primary ? "!bg-gradient-to-r from-violet-600/70 to-sky-500/50 shadow-[0_0_30px_rgba(168,85,247,.45)]" : ""}`}>
              <span className="tile-glow" />
              <span className="relative w-11 h-11 rounded-xl grid place-items-center bg-black/30 border border-white/15"><m.icon size={20} /></span>
              <span className="relative flex-1">
                <span className="block font-display font-extrabold tracking-[.18em] uppercase">{m.label}</span>
                <span className="block text-sm text-[var(--muted)] font-semibold">{m.sub}</span>
              </span>
              <ChevronRight className="relative opacity-60" />
            </button>
          ))}
        </div>
      </section>

      {/* Right: agent card */}
      <section className="anim-screen" style={{ animationDelay: ".2s" }}>
        <div className="glass glass-edge hud-frame p-6 sm:p-8 relative overflow-hidden">
          <span className="corner tl" /><span className="corner tr" /><span className="corner bl" /><span className="corner br" />
          <div className="label mb-4">Agent profile</div>
          <div className="flex items-center gap-5">
            <div className="anim-float"><Avatar index={profile.avatar} size={96} /></div>
            <div className="min-w-0">
              <div className="font-display text-2xl font-black truncate">{profile.name || "Unknown Agent"}</div>
              <button onClick={() => { sfx.click(); setModal("agent"); }} className="mt-2 chip hover:bg-violet-500/30"><Pencil size={12} /> Edit codename</button>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 mt-7">
            {[
              ["Online", online],
              ["Players", "5–10"],
              ["Spy", "1"],
            ].map(([k, v]) => (
              <div key={k} className="rounded-2xl bg-black/25 border border-white/10 p-3 text-center">
                <div className="font-display text-2xl font-black text-neon">{v}</div>
                <div className="label !text-[9px] mt-1">{k}</div>
              </div>
            ))}
          </div>
          <div className="mt-7">
            <div className="label mb-3">Quick briefing</div>
            <HowToPlay compact />
          </div>
        </div>
      </section>

      <Modal open={modal === "how"} onClose={() => setModal(null)} title="How to Play" wide><HowToPlay /></Modal>

      <Modal open={modal === "features"} onClose={() => setModal(null)} title="Features" wide>
        <div className="grid sm:grid-cols-3 gap-3 stagger">
          {FEATURES.map(([i, t, d]) => (
            <div key={t} className="glass p-4">
              <div className="text-3xl">{i}</div>
              <div className="font-display text-xs tracking-widest uppercase mt-2">{t}</div>
              <p className="text-[var(--muted)] text-sm font-semibold mt-1">{d}</p>
            </div>
          ))}
        </div>
      </Modal>

      <Modal open={modal === "agent"} onClose={() => setModal(null)} title="Agent Profile">
        <AgentEditor profile={profile} onSave={(p) => { setProfile(saveProfile(p)); setModal(null); }} />
      </Modal>

      <Modal open={modal === "stats"} onClose={() => setModal(null)} title="My Stats" wide>
        {stats && (
          <>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {[["Games", stats.games], ["Wins", stats.wins], ["As Spy", stats.spyGames], ["Spy wins", stats.spyWins], ["Group wins", stats.groupWins], ["Word guesses", stats.correctGuesses]].map(([k, v]) => (
                <div key={k} className="rounded-2xl bg-black/25 border border-white/10 p-3 text-center">
                  <div className="font-display text-2xl font-black text-neon">{v}</div>
                  <div className="label !text-[8px] mt-1">{k}</div>
                </div>
              ))}
            </div>
            <div className="label mt-6 mb-2">Game history</div>
            {history.length === 0 ? <p className="text-[var(--muted)]">No games yet. Create a room and play!</p> : (
              <div className="flex flex-col gap-2">
                {history.slice(0, 15).map((h) => (
                  <div key={h.id} className="glass flex items-center gap-3 px-4 py-3 !rounded-xl">
                    <span className={`chip ${h.won ? "!bg-emerald-500/20 !border-emerald-400/40" : "!bg-rose-500/20 !border-rose-400/40"}`}>{h.won ? "WIN" : "LOSS"}</span>
                    <span className="font-bold flex-1 truncate">{h.wasSpy ? "🕵️ You were the Spy" : "🔑 Agent"} · {wordLabel(h.word)}</span>
                    <span className="text-xs text-[var(--muted)]">{new Date(h.at).toLocaleDateString()}</span>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </Modal>
    </div>
  );
}

function AgentEditor({ profile, onSave }) {
  const [name, setName] = useState(profile.name);
  const [avatar, setAvatar] = useState(profile.avatar);
  return (
    <div className="flex flex-col gap-4">
      <input className="input-game" maxLength={16} value={name} onChange={(e) => setName(e.target.value)} placeholder="Codename" />
      <div className="grid grid-cols-6 gap-2">
        {AVATARS.map((_, i) => (
          <button key={i} onClick={() => { sfx.hover(); setAvatar(i); }} className={`select-tile rounded-2xl border border-transparent p-1 grid place-items-center`} data-on={avatar === i}>
            <Avatar index={i} size={44} />
          </button>
        ))}
      </div>
      <button className="btn-game" onClick={() => { sfx.click(); onSave({ name, avatar }); }}>Save</button>
    </div>
  );
}
