"use client";
import { Suspense, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import ScreenHeader from "@/components/ScreenHeader";
import GameLobby from "@/components/GameLobby";
import Loader from "@/components/Loader";
import { useRoom } from "@/hooks/useRoom";
import { leaveRoom } from "@/services/roomService";
import { PHASES } from "@/utils/gameConstants";

function LobbyInner() {
  const router = useRouter();
  const code = (useSearchParams().get("code") || "").toUpperCase();
  const { room, me, isHost, loading, inRoom } = useRoom(code);

  useEffect(() => {
    if (loading) return;
    if (!room || !inRoom) return router.replace(`/join-room?code=${code}`);
    if (room.phase === PHASES.RESULTS) router.replace(`/results?code=${code}`);
    else if (room.phase !== PHASES.LOBBY) router.replace(`/game?code=${code}`);
  }, [room, loading, inRoom, code, router]);

  if (loading || !room || !inRoom) return <Loader text="Connecting to room…" />;

  const leave = () => { leaveRoom(code); router.push("/"); };
  return (
    <>
      <ScreenHeader kicker="Lobby" title={`Room ${code}`} onBack={leave} />
      <GameLobby room={room} me={me} isHost={isHost} onLeave={leave} />
    </>
  );
}

export default function Lobby() {
  return <Suspense fallback={<Loader />}><LobbyInner /></Suspense>;
}
