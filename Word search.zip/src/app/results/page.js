"use client";
import { Suspense, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Loader from "@/components/Loader";
import ResultsPanel from "@/components/ResultsPanel";
import Scoreboard from "@/components/Scoreboard";
import Reactions from "@/components/Reactions";
import { useToast } from "@/components/Toast";
import { useRoom } from "@/hooks/useRoom";
import { playAgain } from "@/services/gameService";
import { leaveRoom } from "@/services/roomService";
import { recordHistory } from "@/services/playerService";
import { PHASES } from "@/utils/gameConstants";

function ResultsInner() {
  const router = useRouter();
  const toast = useToast();
  const code = (useSearchParams().get("code") || "").toUpperCase();
  const { room, me, isHost, loading, inRoom } = useRoom(code);

  useEffect(() => {
    if (loading) return;
    if (!room || !inRoom) return router.replace(`/join-room?code=${code}`);
    if (room.phase === PHASES.LOBBY) router.replace(`/lobby?code=${code}`);
    else if (room.phase !== PHASES.RESULTS) router.replace(`/game?code=${code}`);
  }, [room, loading, inRoom, code, router]);

  // save to this device's game history (My Stats)
  useEffect(() => {
    if (!room || room.phase !== PHASES.RESULTS || !room.game.outcome) return;
    const wasSpy = room.game.spyId === me;
    recordHistory({
      id: `${room.code}-${room.round}`, at: Date.now(), word: room.game.word, wasSpy,
      won: (room.game.outcome.winner === "spy") === wasSpy, guessedRight: wasSpy && room.game.guessedRight,
    });
  }, [room, me]);

  if (loading || !room || !inRoom || room.phase !== PHASES.RESULTS) return <Loader text="Loading results…" />;

  return (
    <div className="flex flex-col gap-5">
      <ResultsPanel room={room} me={me} isHost={isHost}
        onPlayAgain={() => { try { playAgain(code); } catch (e) { toast(e.message, "error"); } }}
        onLeave={() => { leaveRoom(code); router.push("/"); }} />
      <Scoreboard room={room} me={me} />
      <Reactions room={room} />
    </div>
  );
}

export default function Results() {
  return <Suspense fallback={<Loader />}><ResultsInner /></Suspense>;
}
