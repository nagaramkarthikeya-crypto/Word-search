"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Rocket, Minus, Plus, Save } from "lucide-react";
import ScreenHeader from "@/components/ScreenHeader";
import ProfilePicker from "@/components/ProfilePicker";
import GameButton from "@/components/GameButton";
import { useToast } from "@/components/Toast";
import { CATEGORIES } from "@/utils/wordCategories";
import { DURATIONS, TIE_RULES, MIN_PLAYERS, MAX_PLAYERS } from "@/utils/gameConstants";
import { getProfile, validateNickname, getCustomCategories, saveCustomCategories } from "@/services/playerService";
import { createRoom } from "@/services/roomService";
import { sfx } from "@/utils/sfx";

function Section({ title, children }) {
  return (
    <div className="glass p-5 sm:p-6">
      <div className="label mb-4">{title}</div>
      {children}
    </div>
  );
}

export default function CreateRoom() {
  const router = useRouter();
  const toast = useToast();
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState(0);
  const [maxPlayers, setMax] = useState(8);
  const [category, setCategory] = useState("random");
  const [lang, setLang] = useState("en");
  const [duration, setDuration] = useState("normal");
  const [tieRule, setTieRule] = useState("revote");
  const [custom, setCustom] = useState("");
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const p = getProfile();
    setName(p.name);
    setAvatar(p.avatar);
    setCustom(getCustomCategories().join(", "));
  }, []);

  const customWords = custom.split(/[,\n]/).map((w) => w.trim()).filter(Boolean);

  function submit() {
    const e = validateNickname(name);
    setErr(e);
    if (e) return sfx.error();
    try {
      setBusy(true);
      const code = createRoom({ name, avatar, maxPlayers, category, lang, duration, tieRule, customWords });
      sfx.join();
      router.push(`/lobby?code=${code}`);
    } catch (x) {
      toast(x.message, "error");
      setBusy(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto">
      <ScreenHeader kicker="New mission" title="Create Room" />
      <div className="flex flex-col gap-4 stagger">
        <Section title="Agent">
          <ProfilePicker name={name} setName={(v) => { setName(v); setErr(null); }} avatar={avatar} setAvatar={setAvatar} error={err} />
        </Section>

        <Section title="Player limit">
          <div className="flex items-center justify-center gap-6">
            <button className="btn-game secondary sm !p-3" onClick={() => { sfx.click(); setMax((m) => Math.max(MIN_PLAYERS, m - 1)); }} aria-label="Fewer"><Minus /></button>
            <div className="text-center">
              <div key={maxPlayers} className="font-display text-6xl font-black text-neon anim-pop">{maxPlayers}</div>
              <div className="label">players max</div>
            </div>
            <button className="btn-game secondary sm !p-3" onClick={() => { sfx.click(); setMax((m) => Math.min(MAX_PLAYERS, m + 1)); }} aria-label="More"><Plus /></button>
          </div>
          <div className="flex gap-1.5 justify-center mt-4">
            {Array.from({ length: MAX_PLAYERS }, (_, i) => (
              <span key={i} className={`h-2 w-6 rounded-full transition ${i < maxPlayers ? "bg-gradient-to-r from-violet-500 to-sky-400 shadow-[0_0_8px_#a855f7]" : "bg-white/10"}`} />
            ))}
          </div>
        </Section>

        <Section title="Word category">
          <div className="flex gap-2 mb-4">
            {[["en", "English"], ["te", "తెలుగు"]].map(([k, l]) => (
              <button key={k} data-on={lang === k} disabled={category === "custom"} onClick={() => { sfx.hover(); setLang(k); }}
                className="select-tile flex-1 rounded-xl border border-white/10 py-2.5 font-bold tracking-wider disabled:opacity-40">{l}</button>
            ))}
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {CATEGORIES.map((c) => (
              <button key={c.id} data-on={category === c.id} onClick={() => { sfx.hover(); setCategory(c.id); }}
                className="select-tile rounded-2xl border border-white/10 py-4 flex flex-col items-center gap-1">
                <span className="text-3xl">{c.icon}</span>
                <span className="font-display text-[11px] tracking-widest uppercase">{c.label}</span>
              </button>
            ))}
          </div>
          {category === "custom" && (
            <div className="mt-4 anim-screen">
              <label className="label">Your words (comma or new line separated, min 3)</label>
              <textarea className="input-game mt-1 min-h-28" value={custom} onChange={(e) => setCustom(e.target.value)}
                placeholder="Hostel, Canteen, Exam, Bunk, Proxy" />
              <div className="flex items-center justify-between mt-2">
                <span className="text-sm text-[var(--muted)] font-semibold">{customWords.length} words</span>
                <button className="chip hover:bg-violet-500/30" onClick={() => { saveCustomCategories(customWords); sfx.click(); toast("Custom words saved on this device", "ok"); }}>
                  <Save size={12} /> Save list
                </button>
              </div>
            </div>
          )}
        </Section>

        <Section title="Game duration">
          <div className="grid grid-cols-3 gap-2">
            {Object.entries(DURATIONS).map(([k, d]) => (
              <button key={k} data-on={duration === k} onClick={() => { sfx.hover(); setDuration(k); }}
                className="select-tile rounded-2xl border border-white/10 py-4">
                <div className="font-display text-sm tracking-widest uppercase">{d.label}</div>
                <div className="text-[var(--muted)] text-sm font-semibold">{d.sub}</div>
              </button>
            ))}
          </div>
        </Section>

        <Section title="Tie breaker">
          <div className="grid grid-cols-2 gap-2">
            {Object.entries(TIE_RULES).map(([k, d]) => (
              <button key={k} data-on={tieRule === k} onClick={() => { sfx.hover(); setTieRule(k); }}
                className="select-tile rounded-2xl border border-white/10 py-4 px-3">
                <div className="font-display text-xs tracking-widest uppercase">{d.label}</div>
                <div className="text-[var(--muted)] text-sm font-semibold">{d.sub}</div>
              </button>
            ))}
          </div>
        </Section>

        <GameButton onClick={submit} disabled={busy} className="w-full text-lg !py-5 mt-2" sound="">
          <Rocket /> {busy ? "Creating…" : "Create Room"}
        </GameButton>
      </div>
    </div>
  );
}
