"use client";
import { Suspense, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { CheckCircle2, LogOut } from "lucide-react";
import Loader from "@/components/Loader";
import SecretCard from "@/components/SecretCard";
import ClueRound from "@/components/ClueRound";
import VotingPanel from "@/components/VotingPanel";
import SpyGuess from "@/components/SpyGuess";
import PhaseBanner from "@/components/PhaseBanner";
import Reactions from "@/components/Reactions";
import TimerRing from "@/components/TimerRing";
import GameButton from "@/components/GameButton";
import Avatar from "@/components/Avatar";
import { useToast } from "@/components/Toast";
import { useRoom } from "@/hooks/useRoom";
import { useGame } from "@/hooks/useGame";
import { markReady, hostSkipTurn } from "@/services/gameService";
import { leaveRoom } from "@/services/roomService";
import { PHASES, DURATIONS } from "@/utils/gameConstants";

const PHASE_LABEL = { reveal: "Secret card", clues: "Clue round", voting: "Voting", spyGuess: "Final guess" };

function GameInner() {
  const router = useRouter();
  const toast = useToast();
  const code = (useSearchParams().get("code") || "").toUpperCase();
  const { room, me, isHost, loading, inRoom } = useRoom(code);
  const game = useGame(room, me);

  useEffect(() => {
    if (loading) return;
    if (!room || !inRoom) return router.replace(`/join-room?code=${code}`);
    if (room.phase === PHASES.LOBBY) router.replace(`/lobby?code=${code}`);
    if (room.phase === PHASES.RESULTS) router.replace(`/results?code=${code}`);
  }, [room, loading, inRoom, code, router]);

  if (loading || !room || !inRoom || room.phase === PHASES.LOBBY || room.phase === PHASES.RESULTS) return <Loader text="Syncing game…" />;

  const leave = () => { if (confirm("Leave this game?")) { leaveRoom(code); router.push("/"); } };
  const ready = room.game.ready || {};
  const humans = game.players.filter((p) => !p.isBot);

  return (
    <div className="flex flex-col gap-5">
      <PhaseBanner phase={room.phase} round={room.round} revote={room.game.revoteCount} />

      {/* HUD */}
      <div className="glass flex items-center gap-3 px-4 py-3 anim-screen">
        <span className="chip">Room {code}</span>
        <span className="chip">Round {room.round}</span>
        <span className="font-display tracking-widest text-sm sm:text-base font-black text-neon mr-auto">{PHASE_LABEL[room.phase]?.toUpperCase()}</span>
        <button onClick={leave} className="p-2 rounded-xl hover:bg-rose-500/20 text-[var(--muted)] hover:text-rose-300" aria-label="Leave"><LogOut size={18} /></button>
      </div>

      <div key={room.phase} className="anim-screen">
        {room.phase === PHASES.REVEAL && (
          <div className="grid lg:grid-cols-[1fr_320px] gap-6 items-start">
            <div className="flex flex-col items-center gap-5 py-2">
              <SecretCard secret={game.secret} />
              {ready[me] ? (
                <div className="glass px-5 py-3 font-bold flex items-center gap-2 text-emerald-300"><CheckCircle2 size={18} /> Ready — waiting for others</div>
              ) : (
                <GameButton onClick={() => markReady(code)} className="!px-8">I&apos;ve memorised it</GameButton>
              )}
            </div>
            <div className="glass p-5 flex flex-col items-center gap-4">
              <TimerRing seconds={game.timeLeft} total={DURATIONS[room.settings.duration]?.reveal || 15} size={96} />
              <div className="label">Clue round starts soon</div>
              <div className="flex flex-wrap justify-center gap-2">
                {humans.map((p) => (
                  <div key={p.id} className={`flex flex-col items-center w-14 ${ready[p.id] ? "" : "opacity-40"}`}>
                    <Avatar index={p.avatar} size={38} />
                    <span className="text-[10px] font-bold truncate w-full text-center">{ready[p.id] ? "✓ " : ""}{p.name}</span>
                  </div>
                ))}
              </div>
              {isHost && <GameButton variant="secondary" size="sm" onClick={() => { try { hostSkipTurn(code); } catch (e) { toast(e.message, "error"); } }}>Start clues now</GameButton>}
            </div>
          </div>
        )}
        {room.phase === PHASES.CLUES && <ClueRound room={room} me={me} isHost={isHost} game={game} />}
        {room.phase === PHASES.VOTING && <VotingPanel room={room} me={me} isHost={isHost} game={game} />}
        {room.phase === PHASES.SPY_GUESS && <SpyGuess room={room} me={me} game={game} />}
      </div>

      <div className="mt-2"><Reactions room={room} /></div>
    </div>
  );
}

export default function GamePage() {
  return <Suspense fallback={<Loader />}><GameInner /></Suspense>;
}
