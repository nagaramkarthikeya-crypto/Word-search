// Tiny synth sound effects (WebAudio, no files) + haptics.
let ctx = null;
let muted = false;

if (typeof window !== "undefined") {
  muted = localStorage.getItem("sw_muted") === "1";
}

export function unlockAudio() {
  if (typeof window === "undefined") return;
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (AC) ctx = new AC();
  }
  if (ctx && ctx.state === "suspended") ctx.resume();
}

export function isMuted() {
  return muted;
}
export function setMuted(v) {
  muted = v;
  localStorage.setItem("sw_muted", v ? "1" : "0");
}

function tone(freq, dur = 0.12, type = "sine", vol = 0.12, delay = 0, slideTo = null) {
  if (muted || !ctx) return;
  const t = ctx.currentTime + delay;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(ctx.destination);
  o.start(t);
  o.stop(t + dur + 0.02);
}

export function haptic(pattern = 15) {
  if (typeof navigator !== "undefined" && navigator.vibrate) {
    try {
      navigator.vibrate(pattern);
    } catch {}
  }
}

export const sfx = {
  hover: () => tone(880, 0.05, "sine", 0.03),
  click: () => {
    tone(520, 0.06, "square", 0.05);
    tone(780, 0.08, "sine", 0.05, 0.04);
    haptic(10);
  },
  back: () => tone(420, 0.1, "triangle", 0.06, 0, 260),
  join: () => {
    tone(523, 0.1, "sine", 0.08);
    tone(659, 0.1, "sine", 0.08, 0.08);
    tone(784, 0.16, "sine", 0.08, 0.16);
  },
  boot: () => {
    tone(110, 0.6, "sawtooth", 0.05, 0, 440);
    tone(880, 0.25, "sine", 0.06, 0.55);
  },
  tick: () => tone(1200, 0.03, "square", 0.03),
  reveal: () => {
    tone(200, 0.4, "sawtooth", 0.06, 0, 900);
    tone(1046, 0.3, "sine", 0.07, 0.35);
    haptic([30, 40, 60]);
  },
  spy: () => {
    tone(140, 0.5, "sawtooth", 0.09, 0, 70);
    tone(98, 0.6, "square", 0.05, 0.15);
    haptic([80, 50, 80, 50, 160]);
  },
  vote: () => {
    tone(330, 0.08, "square", 0.06);
    tone(440, 0.12, "square", 0.06, 0.07);
    haptic(25);
  },
  win: () => {
    [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.22, "triangle", 0.08, i * 0.11));
    haptic([40, 30, 40, 30, 120]);
  },
  lose: () => {
    [392, 349, 311, 262].forEach((f, i) => tone(f, 0.26, "sawtooth", 0.05, i * 0.14));
    haptic(200);
  },
  error: () => {
    tone(180, 0.15, "square", 0.07);
    haptic([50, 30, 50]);
  },
};
