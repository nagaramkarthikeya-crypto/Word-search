// Word banks. English words are plain strings.
// Telugu words are { w: Telugu script, r: romanized } so players can guess in either.

export const CATEGORIES = [
  { id: "animals", label: "Animals", icon: "🐾" },
  { id: "movies", label: "Movies", icon: "🎬" },
  { id: "food", label: "Food", icon: "🍛" },
  { id: "technology", label: "Technology", icon: "💻" },
  { id: "places", label: "Places", icon: "🗺️" },
  { id: "sports", label: "Sports", icon: "🏏" },
  { id: "random", label: "Random", icon: "🎲" },
  { id: "custom", label: "Custom", icon: "✏️" },
];

const EN = {
  animals: ["Elephant", "Tiger", "Penguin", "Giraffe", "Dolphin", "Kangaroo", "Peacock", "Crocodile", "Camel", "Owl", "Monkey", "Shark", "Horse", "Parrot", "Snake"],
  movies: ["Baahubali", "RRR", "Pushpa", "Titanic", "Avatar", "Inception", "Frozen", "Jurassic Park", "Spider-Man", "Avengers", "KGF", "Interstellar", "Joker", "Harry Potter", "Eega"],
  food: ["Biryani", "Pizza", "Dosa", "Ice Cream", "Burger", "Samosa", "Idli", "Pani Puri", "Noodles", "Chocolate", "Mango", "Pesarattu", "Gulab Jamun", "Sandwich", "Popcorn"],
  technology: ["Smartphone", "Laptop", "Wi-Fi", "Robot", "Drone", "Bluetooth", "Smartwatch", "Keyboard", "Satellite", "Headphones", "Instagram", "ChatGPT", "Router", "Camera", "Power Bank"],
  places: ["Beach", "Airport", "Hospital", "Library", "Cinema Hall", "Railway Station", "Temple", "School", "Mall", "Zoo", "Hotel", "Gym", "Market", "Stadium", "Hill Station"],
  sports: ["Cricket", "Football", "Badminton", "Kabaddi", "Tennis", "Chess", "Basketball", "Swimming", "Hockey", "Boxing", "Volleyball", "Carrom", "Wrestling", "Cycling", "Archery"],
};

const TE = {
  animals: [{ w: "ఏనుగు", r: "Enugu" }, { w: "పులి", r: "Puli" }, { w: "కోతి", r: "Kothi" }, { w: "ఆవు", r: "Aavu" }, { w: "పాము", r: "Paamu" }, { w: "నెమలి", r: "Nemali" }, { w: "గుర్రం", r: "Gurram" }, { w: "చిలుక", r: "Chiluka" }, { w: "కుక్క", r: "Kukka" }, { w: "పిల్లి", r: "Pilli" }, { w: "సింహం", r: "Simham" }, { w: "చేప", r: "Chepa" }],
  movies: [{ w: "బాహుబలి", r: "Baahubali" }, { w: "పుష్ప", r: "Pushpa" }, { w: "మగధీర", r: "Magadheera" }, { w: "ఈగ", r: "Eega" }, { w: "అరుంధతి", r: "Arundhati" }, { w: "పోకిరి", r: "Pokiri" }, { w: "జెర్సీ", r: "Jersey" }, { w: "రంగస్థలం", r: "Rangasthalam" }, { w: "మహానటి", r: "Mahanati" }, { w: "అల వైకుంఠపురములో", r: "Ala Vaikunthapurramuloo" }],
  food: [{ w: "బిర్యానీ", r: "Biryani" }, { w: "దోశ", r: "Dosa" }, { w: "ఇడ్లీ", r: "Idli" }, { w: "పెసరట్టు", r: "Pesarattu" }, { w: "పులిహోర", r: "Pulihora" }, { w: "గోంగూర", r: "Gongura" }, { w: "అరిసెలు", r: "Ariselu" }, { w: "పూతరేకులు", r: "Pootharekulu" }, { w: "మామిడి", r: "Mamidi" }, { w: "పాయసం", r: "Payasam" }, { w: "బొబ్బట్లు", r: "Bobbatlu" }],
  technology: [{ w: "సెల్ ఫోన్", r: "Cell Phone" }, { w: "కంప్యూటర్", r: "Computer" }, { w: "టీవీ", r: "TV" }, { w: "రేడియో", r: "Radio" }, { w: "కెమెరా", r: "Camera" }, { w: "రోబో", r: "Robo" }, { w: "ఉపగ్రహం", r: "Upagraham" }, { w: "బ్యాటరీ", r: "Battery" }],
  places: [{ w: "తిరుపతి", r: "Tirupati" }, { w: "విశాఖపట్నం", r: "Visakhapatnam" }, { w: "హైదరాబాద్", r: "Hyderabad" }, { w: "అరకు", r: "Araku" }, { w: "బడి", r: "Badi" }, { w: "గుడి", r: "Gudi" }, { w: "సంత", r: "Santha" }, { w: "సముద్రం", r: "Samudram" }, { w: "ఆసుపత్రి", r: "Aasupatri" }, { w: "రైల్వే స్టేషన్", r: "Railway Station" }],
  sports: [{ w: "క్రికెట్", r: "Cricket" }, { w: "కబడ్డీ", r: "Kabaddi" }, { w: "చదరంగం", r: "Chadarangam" }, { w: "ఖో ఖో", r: "Kho Kho" }, { w: "గోలీలు", r: "Golilu" }, { w: "బ్యాడ్మింటన్", r: "Badminton" }, { w: "కుస్తీ", r: "Kusthi" }, { w: "గిల్లీ దండా", r: "Gilli Danda" }],
};

// Generic hints bots use in the local demo (Phase 2 only)
export const BOT_HINTS = {
  animals: ["wild", "has a tail", "zoo", "fast", "jungle", "big", "cute", "dangerous"],
  movies: ["blockbuster", "action", "hero", "theatre", "songs", "sequel", "box office", "villain"],
  food: ["tasty", "spicy", "sweet", "street", "breakfast", "hot", "festival", "hungry"],
  technology: ["battery", "screen", "internet", "charge", "smart", "gadget", "signal", "app"],
  places: ["crowd", "travel", "tickets", "weekend", "busy", "visit", "photos", "family"],
  sports: ["team", "score", "ball", "match", "trophy", "practice", "champion", "stadium"],
  custom: ["hmm", "obviously", "classic", "everyday", "famous", "you know", "close", "common"],
};

export function getWordBank(category, lang = "en", customWords = []) {
  if (category === "custom") return customWords.filter(Boolean).map((w) => w.trim()).filter(Boolean);
  const bank = lang === "te" ? TE : EN;
  if (category === "random") return Object.values(bank).flat();
  return bank[category] || [];
}

export function categoryOfWord(word, lang = "en") {
  const bank = lang === "te" ? TE : EN;
  for (const [cat, list] of Object.entries(bank)) {
    if (list.some((x) => wordLabel(x) === wordLabel(word))) return cat;
  }
  return "custom";
}

export function wordLabel(word) {
  if (!word) return "";
  return typeof word === "string" ? word : `${word.w} · ${word.r}`;
}

const norm = (s) => String(s || "").toLowerCase().replace(/[^\p{L}\p{N}]/gu, "");

export function isCorrectGuess(word, guess) {
  const g = norm(guess);
  if (!g) return false;
  if (typeof word === "string") return norm(word) === g;
  return norm(word.w) === g || norm(word.r) === g;
}

export function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}
