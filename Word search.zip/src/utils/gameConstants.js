// Shared game constants. Used by the UI, the local demo engine, and (Phase 4+) Cloud Functions.

export const MIN_PLAYERS = 5;
export const MAX_PLAYERS = 10;
export const ROOM_CODE_LENGTH = 6;
export const ROOM_TTL_MS = 2 * 60 * 60 * 1000; // 2 hours of inactivity
export const PRESENCE_INTERVAL_MS = 3000;
export const OFFLINE_AFTER_MS = 12000;

export const PHASES = {
  LOBBY: "lobby",
  REVEAL: "reveal",
  CLUES: "clues",
  VOTING: "voting",
  SPY_GUESS: "spyGuess",
  RESULTS: "results",
};

// "Game duration" from Create Room => per-phase timers (seconds)
export const DURATIONS = {
  quick: { label: "Quick", sub: "20s clues", reveal: 12, clue: 20, vote: 40, guess: 25 },
  normal: { label: "Normal", sub: "35s clues", reveal: 15, clue: 35, vote: 60, guess: 30 },
  long: { label: "Long", sub: "60s clues", reveal: 20, clue: 60, vote: 90, guess: 45 },
};

export const TIE_RULES = {
  revote: { label: "Revote once", sub: "Tied players face a revote" },
  spyWins: { label: "Spy wins ties", sub: "No majority = Spy escapes" },
};

export const REACTIONS = ["😂", "🤨", "😱", "🕵️", "🔥", "🤡", "👀", "💀"];

export const AVATARS = [
  { emoji: "🦊", from: "#8b5cf6", to: "#3b82f6" },
  { emoji: "🐺", from: "#6366f1", to: "#06b6d4" },
  { emoji: "🦉", from: "#a855f7", to: "#ec4899" },
  { emoji: "🐍", from: "#22d3ee", to: "#7c3aed" },
  { emoji: "🦅", from: "#3b82f6", to: "#a855f7" },
  { emoji: "🐯", from: "#f472b6", to: "#7c3aed" },
  { emoji: "🦇", from: "#4f46e5", to: "#9333ea" },
  { emoji: "🐙", from: "#0ea5e9", to: "#8b5cf6" },
  { emoji: "🦁", from: "#c026d3", to: "#2563eb" },
  { emoji: "🐼", from: "#7c3aed", to: "#22d3ee" },
  { emoji: "🦈", from: "#2563eb", to: "#c084fc" },
  { emoji: "🐸", from: "#14b8a6", to: "#6366f1" },
];

export const BOT_NAMES = ["Shadow", "Viper", "Nova", "Raven", "Echo", "Blaze", "Ghost", "Cipher", "Pixel", "Onyx"];
