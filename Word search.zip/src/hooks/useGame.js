"use client";
import { useMemo } from "react";
import { useNow } from "./useNow";
import { getMySecret } from "@/services/gameService";
import { PHASES } from "@/utils/gameConstants";

// Derived, per-player view of the running game.
export function useGame(room, me) {
  const now = useNow(250);
  const secret = useMemo(() => getMySecret(room), [room]);
  if (!room) return { now, secret: null };
  const g = room.game || {};
  const timeLeft = room.phaseEndsAt ? Math.max(0, Math.ceil((room.phaseEndsAt - now) / 1000)) : 0;
  const players = room.order.map((id) => room.players[id]).filter(Boolean);
  const currentTurnId = room.phase === PHASES.CLUES ? g.turnOrder?.[g.turnIndex] : null;
  const votedCount = Object.keys(g.votes || {}).length;
  return {
    now,
    secret,
    timeLeft,
    players,
    currentTurnId,
    isMyTurn: currentTurnId === me,
    myVote: g.votes?.[me] || null,
    votedCount,
    hasVoted: (id) => !!g.votes?.[id],
  };
}
