"use client";
import { useEffect, useState } from "react";
import { subscribeRoom, heartbeat } from "@/services/roomService";
import { hostTick } from "@/services/gameService";
import { getPlayerId } from "@/services/playerService";
import { PRESENCE_INTERVAL_MS } from "@/utils/gameConstants";

// Live room state + presence heartbeat + host-driven game clock.
export function useRoom(code) {
  const [room, setRoom] = useState(undefined); // undefined = loading, null = missing
  const [me, setMe] = useState(null);

  useEffect(() => {
    if (!code) return;
    setMe(getPlayerId());
    const unsub = subscribeRoom(code, setRoom);
    heartbeat(code);
    const hb = setInterval(() => heartbeat(code), PRESENCE_INTERVAL_MS);
    const clock = setInterval(() => hostTick(code), 700);
    const onVis = () => document.visibilityState === "visible" && heartbeat(code);
    document.addEventListener("visibilitychange", onVis);
    return () => {
      unsub();
      clearInterval(hb);
      clearInterval(clock);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [code]);

  const player = room && me ? room.players[me] : null;
  return {
    room,
    me,
    player,
    loading: room === undefined,
    isHost: !!room && room.hostId === me,
    inRoom: !!player,
  };
}
