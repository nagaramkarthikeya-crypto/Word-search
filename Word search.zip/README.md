# SECRET WORD — Phase 1 + 2

## Phase 1: Setup (Windows PowerShell / VS Code terminal)
1. Install Node.js 20+ (https://nodejs.org)
2. Extract this zip, open the `secret-word` folder in VS Code
3. Run:
   npm install
   npm run dev
4. Open http://localhost:3000

## Phase 2: How to test (no Firebase needed yet)
- Boot screen -> TAP TO START -> main menu.
- Create Room -> nickname, player limit, category (English/Telugu/Custom), duration, tie rule -> Create.
- Lobby: click "Add test bot" 4 times (5 players) -> Start Game.
- Real multiplayer test on one laptop: open the invite link in NEW TABS (each tab = a different player).
- Secret card: press & HOLD the card to reveal, release to hide.
- Clue round: type your clue when it's your turn. Host can Skip turn / Start voting now.
- Voting: pick a suspect -> Accuse. If the Spy is caught, the Spy gets one final guess.
- Results: Spy + word reveal, vote bars, Replay round, Scoreboard, Play Again (host).
- Home > My Stats shows your game history.

## Where files live
src/app/            pages: / , create-room, join-room, lobby, game, results
src/components/     UI: Navbar(HUD), GameLobby, PlayerCard, RoomCode, SecretCard, ClueRound,
                    VotingPanel, SpyGuess, ResultsPanel, Scoreboard, BootScreen, GameBackground...
src/services/       roomService, gameService, playerService (UI only calls these)
                    localEngine.js = Phase 2 demo engine (browser storage + tabs + bots)
src/hooks/          useRoom, useGame, useNow
src/utils/          wordCategories (EN + Telugu), gameConstants, sfx (sounds + haptics)
src/lib/firebase.js Firebase client (used from Phase 3)

## Next phases
Phase 3-6 replace localEngine with Firestore + Cloud Functions behind the same service
functions, so the secret word & Spy live only on the server. UI stays the same.
